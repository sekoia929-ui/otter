# OTTER — Track. Split. Simplify.

Expense tracking + bill splitting. **Stage 1 (this build): complete UI on realistic sample data.**
SQLite (Stage 2), balances hardening (3), Supabase auth (4), sync queue (5) come next, one at a time.

## Run it (GitHub Codespaces + iPad)
```bash
npm install
npm run web        # opens a browser preview — easiest on an iPad (forward port 8081)
npm run tunnel     # or: scan the QR with Expo Go on a phone
npm run typecheck  # TypeScript check
npm run test:logic # money / split / balance tests
```
If `expo install --check` suggests version tweaks, run `npx expo install --fix`.

## What works in Stage 1
Onboarding · welcome/sign up/login/forgot (Zod validation, fake sign-in) · Home dashboard · Activity with date,
category and personal/shared filters · add/edit/delete expenses · split equally, by amount or percent, one or several
payers · groups, friends, requests, per-person and per-group balances, "who owes whom", manual settlements ·
stats charts · settings (currency, theme, notifications, CSV export) · "Preview offline mode" toggle (Settings).
Wallet/QR/P2P/remittance screens are **Coming soon** placeholders — no balances, nothing simulated as live.

## Layout
- `app/` screens (Expo Router) · `src/components/` UI kit (`ui.tsx`, `charts.tsx`)
- `src/lib/` pure logic: `money` (integer minor units), `splits`, `balances`, `validation`
- `src/store/useStore.ts` Zustand store (Stage 2 swaps its data source to SQLite)
- `src/data/sample.ts` demo data · `assets/otter-logo.png` your logo, background removed

## Notes
- Brand blue is `#67C6FE`, sampled from your logo image (your brief said `#63BDF1`). Change `brand.blue` in `src/theme/colors.ts`.
- The supplied logo is small (~190px), so it's upscaled; send a larger file for crisper icons.
- `.env.example` is for Stage 4. Never put the Supabase service-role key in the app.

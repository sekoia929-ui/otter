import React, { useState } from 'react';
import { Button, Card, ErrorBanner, Field, Header, NeedsInternet, Screen, Txt } from '@/components/ui';
import { emailSchema } from '@/lib/validation';
import { useStore } from '@/store/useStore';
import { useRouter } from 'expo-router';

export default function AddFriend() {
  const router = useRouter(); const { sendFriendRequest, simulateOffline, people } = useStore();
  const [email, setEmail] = useState(''); const [name, setName] = useState(''); const [error, setError] = useState<string | null>(null); const [sent, setSent] = useState(false);
  const send = () => {
    const r = emailSchema.safeParse(email); if (!r.success) return setError(r.error.issues[0].message);
    if (people.some((p) => p.email.toLowerCase() === r.data.toLowerCase())) return setError('You already have this person in your list.');
    setError(null); sendFriendRequest(name.trim(), r.data); setSent(true);
  };
  return (
    <Screen>
      <Header title="Add friend" right={<NeedsInternet />} />
      {simulateOffline && <ErrorBanner message="You're offline. Friend requests need an internet connection — try again when you're back online." />}
      {error && <ErrorBanner message={error} />}
      {sent ? (<Card soft style={{ gap: 8 }}><Txt v="h2">Request sent</Txt><Txt muted>They'll appear in your list once they accept.</Txt><Button title="Done" onPress={() => router.back()} /></Card>) : (<>
        <Txt muted>Enter your friend's email. They'll get a request to accept.</Txt>
        <Field label="Name (optional)" value={name} onChangeText={setName} placeholder="Their name" />
        <Field label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="friend@example.com" />
        <Button title="Send request" onPress={send} disabled={simulateOffline} />
      </>)}
    </Screen>
  );
}

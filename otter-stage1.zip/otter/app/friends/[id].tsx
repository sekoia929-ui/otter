import React from 'react';
import { View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ExpenseRow } from '@/components/ExpenseRow';
import { Avatar, Button, Card, EmptyState, Header, Pill, Screen, SectionTitle, Txt } from '@/components/ui';
import { pairBalance } from '@/lib/balances';
import { sortNewest } from '@/lib/derive';
import { formatMoney } from '@/lib/money';
import { ME } from '@/lib/types';
import { useStore } from '@/store/useStore';
import { useTheme } from '@/theme/ThemeProvider';

export default function FriendProfile() {
  const { id } = useLocalSearchParams<{ id: string }>(); const router = useRouter(); const { colors } = useTheme();
  const { people, expenses, settlements, settings, acceptRequest, declineRequest, simulateOffline } = useStore();
  const p = people.find((x) => x.id === id);
  if (!p) return <Screen><Header title="Friend" /><EmptyState icon="person-outline" title="Friend not found" text="They may have been removed." action="Go back" onAction={() => router.back()} /></Screen>;
  const bal = pairBalance(expenses, settlements, ME, p.id);
  const shared = expenses.filter((e) => e.splits.some((s) => s.userId === p.id) || e.payments.some((x) => x.userId === p.id)).sort(sortNewest);
  const m = (v: number) => formatMoney(Math.abs(v), settings.currency);
  return (
    <Screen>
      <Header title="Friend" />
      <Card style={{ alignItems: 'center', gap: 6, paddingVertical: 24 }}>
        <Avatar name={p.name} size={84} /><Txt v="h2">{p.name}</Txt><Txt muted>{p.email}</Txt>
        {p.status === 'outgoing' && <Pill text="REQUEST SENT" tone="yellow" />}
      </Card>
      {p.status === 'incoming' && (
        <Card soft style={{ gap: 10 }}><Txt v="strong">{p.name} sent you a friend request</Txt>
          {simulateOffline && <Txt v="small" muted>Accepting needs an internet connection.</Txt>}
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Button title="Accept" variant="primary" style={{ flex: 1 }} disabled={simulateOffline} onPress={() => acceptRequest(p.id)} />
            <Button title="Decline" variant="outline" style={{ flex: 1 }} disabled={simulateOffline} onPress={() => { declineRequest(p.id); router.back(); }} /></View></Card>)}
      {p.status === 'friend' && (<>
        <Card soft style={{ gap: 4 }}>
          <Txt v="label" muted>Balance</Txt>
          <Txt v="display" color={bal === 0 ? colors.text : bal > 0 ? colors.positive : colors.negative}>{bal === 0 ? 'Settled up' : m(bal)}</Txt>
          <Txt muted>{bal > 0 ? `${p.name.split(' ')[0]} owes you` : bal < 0 ? `You owe ${p.name.split(' ')[0]}` : 'You are all square'}</Txt>
        </Card>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Button title="Split" icon="git-compare" variant="brand" style={{ flex: 1, paddingHorizontal: 12 }} onPress={() => router.push(`/add-expense?mode=shared&friendId=${p.id}`)} />
          <Button title="Settle up" icon="swap-horizontal" variant="outline" style={{ flex: 1, paddingHorizontal: 12 }} onPress={() => router.push(`/settle?with=${p.id}${bal !== 0 ? `&amount=${Math.abs(bal)}&dir=${bal > 0 ? 'receive' : 'pay'}` : ''}`)} />
        </View>
        <SectionTitle title="Shared expenses" />
        <Card style={{ paddingVertical: 4 }}>{shared.length === 0 ? <EmptyState icon="receipt-outline" title="Nothing shared yet" text="Split an expense to see it here." /> : shared.map((e, i) => <ExpenseRow key={e.id} e={e} last={i === shared.length - 1} />)}</Card>
      </>)}
    </Screen>
  );
}

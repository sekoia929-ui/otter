import React, { useState } from 'react';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Button, Card, ErrorBanner, Field, Header, Screen, Segmented, Txt } from '@/components/ui';
import { formatMoney, minorToInput, parseMinor } from '@/lib/money';
import { ME } from '@/lib/types';
import { personName, useStore } from '@/store/useStore';

/** Records that a payment happened outside the app. No money moves through OTTER. */
export default function Settle() {
  const p = useLocalSearchParams<{ with?: string; from?: string; to?: string; amount?: string; dir?: string; groupId?: string }>(); const router = useRouter();
  const { people, profile, settings, groups, addSettlement } = useStore();
  const explicit = p.from && p.to;
  const [dir, setDir] = useState<'pay' | 'receive'>(p.dir === 'receive' ? 'receive' : 'pay');
  const [withId, setWithId] = useState(p.with ?? null as string | null);
  const [amount, setAmount] = useState(p.amount ? minorToInput(parseInt(p.amount, 10)) : ''); const [note, setNote] = useState(''); const [error, setError] = useState<string | null>(null);
  const name = (id: string) => personName(people, id, profile.name);
  const candidates = p.groupId ? (groups.find((g) => g.id === p.groupId)?.memberIds ?? []).filter((x) => x !== ME) : people.filter((x) => x.status === 'friend').map((x) => x.id);
  const save = () => {
    const minor = parseMinor(amount); if (!minor || minor <= 0) return setError('Enter an amount above 0.');
    const from = explicit ? p.from! : dir === 'pay' ? ME : withId; const to = explicit ? p.to! : dir === 'pay' ? withId : ME;
    if (!from || !to) return setError('Choose who this payment is with.');
    addSettlement({ fromId: from, toId: to, amountMinor: minor, currency: settings.currency, groupId: p.groupId ?? null, date: new Date().toISOString(), note: note.trim() });
    router.back();
  };
  return (
    <Screen>
      <Header title="Record settlement" />
      <Card soft><Txt muted>This only records a payment you made outside OTTER (cash, bank transfer…). No money is moved by the app.</Txt></Card>
      {error && <ErrorBanner message={error} />}
      {explicit ? <Txt v="h2">{name(p.from!)} paid {name(p.to!)}</Txt> : (<>
        <Segmented value={dir} onChange={setDir} options={[{ id: 'pay', label: 'I paid' }, { id: 'receive', label: 'I received' }]} />
        <Txt v="label" muted>{dir === 'pay' ? 'Paid to' : 'Received from'}</Txt>
        {candidates.map((id) => <Button key={id} title={name(id)} variant={withId === id ? 'primary' : 'outline'} onPress={() => setWithId(id)} />)}
      </>)}
      <Field label={`Amount (${settings.currency})`} value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder="0.00" style={{ fontSize: 28, fontWeight: '800', minHeight: 64 }} />
      <Field label="Note (optional)" value={note} onChangeText={setNote} placeholder="e.g. Bank transfer" />
      <Button title={amount ? `Record ${formatMoney(parseMinor(amount) ?? 0, settings.currency)}` : 'Record settlement'} variant="brand" onPress={save} />
    </Screen>
  );
}

import React, { useMemo, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Avatar, Button, Chip, ErrorBanner, Field, Header, Screen, Segmented, Txt, Card, OfflineBanner } from '@/components/ui';
import { CATEGORIES, CategoryId, PAYMENT_METHODS, PaymentMethod } from '@/lib/categories';
import { fromDateInput, toDateInput } from '@/lib/dates';
import { formatMoney, minorToInput, parseMinor } from '@/lib/money';
import { splitEqual, splitPercent, sumLines } from '@/lib/splits';
import { Line, ME } from '@/lib/types';
import { expenseSchema, firstError } from '@/lib/validation';
import { personName, useStore } from '@/store/useStore';

type SplitKind = 'equal' | 'amount' | 'percent';
const ymd = (offset = 0) => { const d = new Date(); d.setDate(d.getDate() - offset); return toDateInput(d); };

export default function AddExpense() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id?: string; mode?: string; groupId?: string; friendId?: string }>();
  const { expenses, people, groups, profile, settings, addExpense, updateExpense } = useStore();
  const editing = params.id ? expenses.find((e) => e.id === params.id) : undefined;
  const friends = people.filter((p) => p.status === 'friend');
  const name = (id: string) => personName(people, id, profile.name);

  const initialShared = editing ? editing.splits.some((s) => s.userId !== ME) || editing.payments.some((p) => p.userId !== ME) : params.mode === 'shared' || !!params.groupId || !!params.friendId;
  const [mode, setMode] = useState<'personal' | 'shared'>(initialShared ? 'shared' : 'personal');
  const [amount, setAmount] = useState(editing ? minorToInput(editing.amountMinor) : '');
  const [desc, setDesc] = useState(editing?.description ?? '');
  const [category, setCategory] = useState<CategoryId>(editing?.category ?? 'food');
  const [date, setDate] = useState(editing ? toDateInput(editing.date) : ymd());
  const [pm, setPm] = useState<PaymentMethod>(editing?.paymentMethod ?? 'card');
  const [groupId, setGroupId] = useState<string | null>(editing ? editing.groupId : params.groupId ?? null);
  const initialParts = editing ? editing.splits.map((s) => s.userId) : params.groupId ? groups.find((g) => g.id === params.groupId)?.memberIds ?? [ME] : params.friendId ? [ME, params.friendId] : [ME];
  const [parts, setParts] = useState<string[]>(initialParts);
  const [multiPay, setMultiPay] = useState(!!editing && editing.payments.length > 1);
  const [payer, setPayer] = useState(editing?.payments[0]?.userId ?? ME);
  const [payAmts, setPayAmts] = useState<Record<string, string>>(editing ? Object.fromEntries(editing.payments.map((p) => [p.userId, minorToInput(p.amountMinor)])) : {});
  const equalMatch = editing ? JSON.stringify(splitEqual(editing.amountMinor, editing.splits.map((s) => s.userId))) === JSON.stringify(editing.splits) : true;
  const [kind, setKind] = useState<SplitKind>(equalMatch ? 'equal' : 'amount');
  const [amtIn, setAmtIn] = useState<Record<string, string>>(editing ? Object.fromEntries(editing.splits.map((s) => [s.userId, minorToInput(s.amountMinor)])) : {});
  const [pctIn, setPctIn] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);

  const total = parseMinor(amount) ?? 0;
  const cur = editing?.currency ?? settings.currency;
  const money = (v: number) => formatMoney(v, cur);

  const pickGroup = (id: string | null) => { setGroupId(id); const g = groups.find((x) => x.id === id); setParts(g ? g.memberIds : [ME]); setPayer(ME); setPayAmts({}); };
  const togglePart = (id: string) => setParts((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  /** Work out the final lines, or an error message. Everything is integer minor units. */
  const calc = useMemo(() => {
    if (mode === 'personal') return { splits: [{ userId: ME, amountMinor: total }] as Line[], payments: [{ userId: ME, amountMinor: total }] as Line[], problem: null as string | null, hint: '' };
    if (parts.length === 0) return { splits: [], payments: [], problem: 'Choose at least one person to split with.', hint: '' };
    let splits: Line[] = []; let problem: string | null = null; let hint = '';
    if (kind === 'equal') splits = splitEqual(total, parts);
    if (kind === 'amount') {
      splits = parts.map((id) => ({ userId: id, amountMinor: parseMinor(amtIn[id] ?? '') ?? 0 }));
      const diff = total - sumLines(splits);
      if (diff !== 0) { problem = diff > 0 ? `${money(diff)} still to assign.` : `Amounts are ${money(-diff)} too high.`; hint = problem; }
    }
    if (kind === 'percent') {
      const pct = Object.fromEntries(parts.map((id) => [id, parseFloat((pctIn[id] ?? '').replace(',', '.')) || 0]));
      const sumPct = Math.round(Object.values(pct).reduce((a, b) => a + b, 0) * 100) / 100;
      if (sumPct !== 100) { problem = `Percentages add up to ${sumPct}% — they need to be 100%.`; hint = problem; }
      splits = splitPercent(total, pct);
    }
    let payments: Line[] = [{ userId: payer, amountMinor: total }];
    if (multiPay) {
      payments = Object.entries(payAmts).map(([userId, v]) => ({ userId, amountMinor: parseMinor(v) ?? 0 })).filter((p) => p.amountMinor > 0);
      const diff = total - sumLines(payments);
      if (!problem && diff !== 0) problem = diff > 0 ? `Payers are ${money(diff)} short of the total.` : `Payers add up to ${money(-diff)} too much.`;
    }
    return { splits, payments, problem, hint };
  }, [mode, parts, kind, amtIn, pctIn, total, payer, multiPay, payAmts]);

  const save = () => {
    const parsed = parseMinor(amount);
    const when = fromDateInput(date);
    const err = firstError(expenseSchema, { description: desc, amountMinor: parsed ?? 0, date: when ?? 'x' }) ?? (when ? null : 'Use the date format YYYY-MM-DD');
    if (err) return setError(err);
    if (calc.problem) return setError(calc.problem);
    setError(null);
    const base = { description: desc.trim(), amountMinor: parsed!, currency: cur, category, date: when!.toISOString(), paymentMethod: pm, groupId: mode === 'shared' ? groupId : null, payments: calc.payments, splits: calc.splits };
    if (editing) updateExpense(editing.id, base); else addExpense(base);
    router.back();
  };

  const candidates = Array.from(new Set([ME, ...parts, ...(groupId ? groups.find((g) => g.id === groupId)?.memberIds ?? [] : friends.map((f) => f.id))]));

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen edges={['top']}>
        <Header title={editing ? 'Edit expense' : 'Add expense'} />
        <OfflineBanner />
        <Segmented value={mode} onChange={setMode} options={[{ id: 'personal', label: 'Personal' }, { id: 'shared', label: 'Split with others' }]} />
        {error && <ErrorBanner message={error} />}
        <Field label={`Amount (${cur})`} value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder="0.00" style={{ fontSize: 32, fontWeight: '800', minHeight: 68 }} />
        <Field label="Description" value={desc} onChangeText={setDesc} placeholder="What was it for?" maxLength={80} />
        <Txt v="label" muted>Category</Txt>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
          {CATEGORIES.map((c) => <Chip key={c.id} label={c.label} icon={c.icon} color={c.color} selected={category === c.id} onPress={() => setCategory(c.id)} />)}
        </ScrollView>
        <Field label="Date (YYYY-MM-DD)" value={date} onChangeText={setDate} placeholder="2026-11-01" keyboardType="numbers-and-punctuation" />
        <View style={{ flexDirection: 'row', gap: 8 }}><Chip label="Today" selected={date === ymd()} onPress={() => setDate(ymd())} /><Chip label="Yesterday" selected={date === ymd(1)} onPress={() => setDate(ymd(1))} /></View>
        <Txt v="label" muted>Payment method</Txt>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {PAYMENT_METHODS.map((p) => <Chip key={p.id} label={p.label} icon={p.icon} selected={pm === p.id} onPress={() => setPm(p.id)} />)}
          <Chip label="Wallet · Coming soon" icon="wallet-outline" disabled />
        </View>

        {mode === 'shared' && (<>
          <Txt v="label" muted>Group (optional)</Txt>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            <Chip label="No group" selected={groupId === null} onPress={() => pickGroup(null)} />
            {groups.map((g) => <Chip key={g.id} label={`${g.emoji} ${g.name}`} selected={groupId === g.id} onPress={() => pickGroup(g.id)} />)}
          </ScrollView>
          <Txt v="label" muted>Split between</Txt>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {candidates.map((id) => <Chip key={id} label={name(id)} selected={parts.includes(id)} onPress={() => togglePart(id)} />)}
          </View>
          <Txt v="label" muted>Who paid?</Txt>
          <Segmented value={multiPay ? 'multi' : 'one'} onChange={(v) => setMultiPay(v === 'multi')} options={[{ id: 'one', label: 'One person' }, { id: 'multi', label: 'Several people' }]} />
          {multiPay ? (
            <Card style={{ gap: 10 }}>{candidates.filter((id) => parts.includes(id)).map((id) => (
              <View key={id} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}><Avatar name={name(id) === 'You' ? profile.name : name(id)} size={36} /><Txt v="strong" style={{ flex: 1 }}>{name(id)}</Txt>
                <Field value={payAmts[id] ?? ''} onChangeText={(v) => setPayAmts({ ...payAmts, [id]: v })} placeholder="0.00" keyboardType="decimal-pad" style={{ width: 110, textAlign: 'right' }} accessibilityLabel={`${name(id)} paid`} /></View>))}</Card>
          ) : (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{candidates.map((id) => <Chip key={id} label={name(id)} selected={payer === id} onPress={() => setPayer(id)} />)}</View>
          )}
          <Txt v="label" muted>How to split</Txt>
          <Segmented value={kind} onChange={setKind} options={[{ id: 'equal', label: 'Equally' }, { id: 'amount', label: 'Amounts' }, { id: 'percent', label: 'Percent' }]} />
          <Card style={{ gap: 10 }}>
            {parts.map((id, i) => (
              <View key={id} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Avatar name={name(id) === 'You' ? profile.name : name(id)} size={36} /><Txt v="strong" style={{ flex: 1 }}>{name(id)}</Txt>
                {kind === 'equal' && <Txt v="strong">{money(calc.splits[i]?.amountMinor ?? 0)}</Txt>}
                {kind === 'amount' && <Field value={amtIn[id] ?? ''} onChangeText={(v) => setAmtIn({ ...amtIn, [id]: v })} placeholder="0.00" keyboardType="decimal-pad" style={{ width: 110, textAlign: 'right' }} accessibilityLabel={`${name(id)} amount`} />}
                {kind === 'percent' && <><Field value={pctIn[id] ?? ''} onChangeText={(v) => setPctIn({ ...pctIn, [id]: v })} placeholder="0" keyboardType="decimal-pad" style={{ width: 80, textAlign: 'right' }} accessibilityLabel={`${name(id)} percent`} /><Txt muted>%</Txt></>}
              </View>
            ))}
            {calc.hint ? <Txt v="small" color="#D03A3F" style={{ fontWeight: '700' }}>{calc.hint}</Txt> : <Txt v="small" muted>Split adds up to the total.</Txt>}
          </Card>
        </>)}
        <Button title={editing ? 'Save changes' : 'Save expense'} onPress={save} variant="brand" />
        <Txt v="small" muted style={{ textAlign: 'center' }}>Saved on this device first, then synced when online.</Txt>
      </Screen>
    </KeyboardAvoidingView>
  );
}

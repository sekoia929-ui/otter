import React from 'react';
import { View, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, Logo, Txt } from '@/components/ui';

export default function Welcome() {
  const router = useRouter();
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#67C6FE' }}>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 14 }}>
        <Logo size={170} />
        <Txt v="display" color="#080808" style={{ fontSize: 48 }}>OTTER</Txt>
        <Txt v="strong" color="#080808">Track. Split. Simplify.</Txt>
      </View>
      <View style={{ padding: 24, gap: 12 }}>
        <Button title="Create account" onPress={() => router.push('/signup')} />
        <Button title="Log in" variant="outline" onPress={() => router.push('/login')} style={{ backgroundColor: '#FFFFFF', borderColor: '#080808' }} />
        <Button title="Continue with Google" icon="logo-google" variant="ghost" onPress={() => Alert.alert('Coming in Stage 5', 'Google sign-in is a placeholder for now. It will be wired up with Supabase Auth.')} />
      </View>
    </SafeAreaView>
  );
}

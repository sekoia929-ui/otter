import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { Button, ErrorBanner, Field, Header, Logo, Screen, Txt } from '@/components/ui';
import { signUpSchema } from '@/lib/validation';
import { useStore } from '@/store/useStore';

export default function SignUp() {
  const router = useRouter(); const signIn = useStore((s) => s.signIn);
  const [name, setName] = useState(''); const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  const submit = () => {
    const r = signUpSchema.safeParse({ name, email, password });
    if (!r.success) { const e: Record<string, string> = {}; r.error.issues.forEach((i) => (e[String(i.path[0])] = i.message)); setErrors(e); return; }
    setErrors({}); setBusy(true);
    setTimeout(() => { setBusy(false); signIn(r.data.name, r.data.email); router.replace('/(tabs)'); }, 500); // Stage 5: Supabase signUp
  };
  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen>
        <Header title="Create account" />
        <Logo size={72} />
        <Txt muted>Free to use. Your expenses stay on your device first.</Txt>
        {Object.keys(errors).length > 0 && <ErrorBanner message="Please fix the highlighted fields." />}
        <Field label="Name" value={name} onChangeText={setName} error={errors.name} placeholder="Alex Rivera" />
        <Field label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" error={errors.email} placeholder="you@example.com" />
        <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry error={errors.password} placeholder="At least 6 characters" />
        <Button title="Sign up" onPress={submit} loading={busy} />
        <Button title="Continue with Google" icon="logo-google" variant="outline" onPress={() => Alert.alert('Coming in Stage 5', 'Google sign-in is a placeholder for now.')} />
        <Txt muted style={{ textAlign: 'center' }} onPress={() => router.replace('/login')}>Already have an account? <Txt v="strong">Log in</Txt></Txt>
      </Screen>
    </KeyboardAvoidingView>
  );
}

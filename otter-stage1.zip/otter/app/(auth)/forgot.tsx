import React, { useState } from 'react';
import { Field, Header, Screen, Button, Txt, Card } from '@/components/ui';
import { emailSchema } from '@/lib/validation';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/theme/ThemeProvider';

export default function Forgot() {
  const { colors } = useTheme();
  const [email, setEmail] = useState(''); const [error, setError] = useState<string | null>(null); const [sent, setSent] = useState(false);
  const submit = () => { const r = emailSchema.safeParse(email); if (!r.success) return setError(r.error.issues[0].message); setError(null); setSent(true); }; // Stage 5: supabase.auth.resetPasswordForEmail
  return (
    <Screen>
      <Header title="Reset password" />
      {sent ? (
        <Card soft style={{ gap: 8 }}><Ionicons name="mail-open" size={28} color={colors.text} /><Txt v="h2">Check your inbox</Txt><Txt muted>If an account exists for {email.trim()}, a reset link is on its way. (Preview only — emails are sent once Supabase is connected.)</Txt></Card>
      ) : (<>
        <Txt muted>Enter your email and we'll send you a reset link. This needs an internet connection.</Txt>
        <Field label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" error={error} placeholder="you@example.com" />
        <Button title="Send reset link" onPress={submit} />
      </>)}
    </Screen>
  );
}

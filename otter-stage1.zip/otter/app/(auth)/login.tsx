import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { Button, ErrorBanner, Field, Header, Logo, Screen, Txt } from '@/components/ui';
import { loginSchema } from '@/lib/validation';
import { useStore } from '@/store/useStore';

export default function Login() {
  const router = useRouter(); const signIn = useStore((s) => s.signIn);
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  const submit = () => {
    const r = loginSchema.safeParse({ email, password });
    if (!r.success) { const e: Record<string, string> = {}; r.error.issues.forEach((i) => (e[String(i.path[0])] = i.message)); setErrors(e); return; }
    setErrors({}); setBusy(true);
    setTimeout(() => { setBusy(false); signIn(undefined, r.data.email); router.replace('/(tabs)'); }, 500); // Stage 5: Supabase signInWithPassword
  };
  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen>
        <Header title="Welcome back" />
        <Logo size={72} />
        <Txt muted>Log in to see your expenses and balances.</Txt>
        {Object.keys(errors).length > 0 && <ErrorBanner message="Please fix the highlighted fields." />}
        <Field label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" error={errors.email} placeholder="you@example.com" />
        <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry error={errors.password} placeholder="••••••••" />
        <Txt v="strong" onPress={() => router.push('/forgot')} style={{ textDecorationLine: 'underline', minHeight: 44, paddingTop: 12 }}>Forgot password?</Txt>
        <Button title="Log in" onPress={submit} loading={busy} />
        <Button title="Continue with Google" icon="logo-google" variant="outline" onPress={() => Alert.alert('Coming in Stage 5', 'Google sign-in is a placeholder for now.')} />
        <Txt muted style={{ textAlign: 'center' }} onPress={() => router.replace('/signup')}>New here? <Txt v="strong">Create an account</Txt></Txt>
      </Screen>
    </KeyboardAvoidingView>
  );
}

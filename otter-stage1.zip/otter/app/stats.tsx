import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Bars, Donut } from '@/components/charts';
import { Card, Header, IconBubble, Screen, Segmented, SectionTitle, Txt, EmptyState } from '@/components/ui';
import { monthRange } from '@/lib/dates';
import { categoryTotals, last6Months, last7Days, pctChange, spendInRange, weekCompare } from '@/lib/derive';
import { formatMoney } from '@/lib/money';
import { useStore } from '@/store/useStore';
import { useTheme } from '@/theme/ThemeProvider';

function Delta({ now, before, label }: { now: number; before: number; label: string }) {
  const { colors } = useTheme(); const c = pctChange(now, before);
  return <Txt v="small" color={c === null ? colors.muted : c > 0 ? colors.negative : colors.positive}>{c === null ? `No ${label} data` : `${c > 0 ? '▲' : c < 0 ? '▼' : '•'} ${Math.abs(c)}% vs ${label}`}</Txt>;
}
export default function Stats() {
  const { expenses, settings } = useStore(); const m = (v: number) => formatMoney(v, settings.currency);
  const [mode, setMode] = useState<'week' | 'month'>('week');
  const d = useMemo(() => {
    const a = monthRange(0), b = monthRange(-1);
    return { cats: categoryTotals(expenses, a.start, a.end), total: spendInRange(expenses, a.start, a.end), prev: spendInRange(expenses, b.start, b.end), w: weekCompare(expenses), week: last7Days(expenses), months: last6Months(expenses), label: a.label };
  }, [expenses]);
  return (
    <Screen>
      <Header title="Statistics" />
      <Card soft style={{ gap: 4 }}><Txt v="label" muted>{d.label}</Txt><Txt v="display">{m(d.total)}</Txt><Delta now={d.total} before={d.prev} label="last month" /></Card>
      <SectionTitle title="Category breakdown" />
      <Card style={{ gap: 14 }}>
        {d.cats.length === 0 ? <EmptyState icon="pie-chart-outline" title="No spending yet this month" text="Add an expense to see your breakdown." /> : (<>
          <View style={{ alignItems: 'center' }}><Donut slices={d.cats.map((c) => ({ value: c.total, color: c.color }))} centerTop="Total" centerBottom={m(d.total)} /></View>
          {d.cats.map((c) => (
            <View key={c.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <IconBubble name={c.icon} color={c.color} size={36} /><Txt v="strong" style={{ flex: 1 }}>{c.label}</Txt>
              <Txt v="small" muted>{Math.round((c.total / d.total) * 100)}%</Txt><Txt v="strong">{m(c.total)}</Txt>
            </View>))}
        </>)}
      </Card>
      <SectionTitle title="Spending trend" />
      <Segmented value={mode} onChange={setMode} options={[{ id: 'week', label: 'Weekly' }, { id: 'month', label: 'Monthly' }]} />
      <Card><Bars data={mode === 'week' ? d.week : d.months} onFormat={m} height={140} /></Card>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Card style={{ flex: 1, gap: 4 }}><Txt v="small" muted>This week</Txt><Txt v="h2">{m(d.w.thisWeek)}</Txt><Delta now={d.w.thisWeek} before={d.w.lastWeek} label="last week" /></Card>
        <Card style={{ flex: 1, gap: 4 }}><Txt v="small" muted>Last week</Txt><Txt v="h2">{m(d.w.lastWeek)}</Txt><Txt v="small" muted>Mon–Sun</Txt></Card>
      </View>
      <Txt v="small" muted>Figures show your share of each expense, including your part of shared bills.</Txt>
    </Screen>
  );
}

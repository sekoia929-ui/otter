import { Redirect } from 'expo-router';
import { useStore } from '@/store/useStore';

/** Front door: onboarding -> welcome/login -> tabs. */
export default function Index() {
  const onboarded = useStore((s) => s.onboarded);
  const signedIn = useStore((s) => s.signedIn);
  if (!onboarded) return <Redirect href="/onboarding" />;
  if (!signedIn) return <Redirect href="/welcome" />;
  return <Redirect href="/(tabs)" />;
}

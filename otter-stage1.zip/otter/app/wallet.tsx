import React from 'react';
import { Card, ComingSoon, Header, IconBubble, Row, Screen, Txt } from '@/components/ui';

// Intentionally NO balances and NO working buttons: payments are not live. This screen only shows the roadmap.
const ITEMS = [
  { icon: 'wallet' as const, title: 'Fiat wallet', sub: 'Partner-powered balance & top-ups', c: '#67C6FE' },
  { icon: 'key' as const, title: 'Crypto wallet', sub: 'Self-custody, you hold the keys', c: '#B7A4F5' },
  { icon: 'qr-code' as const, title: 'QR payments', sub: 'Scan to pay or get paid', c: '#FFD83D' },
  { icon: 'send' as const, title: 'Send to friends', sub: 'Peer-to-peer transfers', c: '#39B982' },
  { icon: 'globe' as const, title: 'Send abroad', sub: 'Cross-border remittances', c: '#F59B7A' },
];
export default function Wallet() {
  return (
    <Screen>
      <Header title="Wallet & payments" />
      <Card soft><Txt v="strong">Not live yet</Txt><Txt muted>OTTER currently tracks and splits expenses only. No money moves through the app. Settle-ups are records you enter by hand.</Txt></Card>
      <Card style={{ paddingVertical: 4 }}>
        {ITEMS.map((x, i) => <Row key={x.title} last={i === ITEMS.length - 1} left={<IconBubble name={x.icon} color={x.c} />} title={x.title} subtitle={x.sub} right={<ComingSoon />} />)}
      </Card>
    </Screen>
  );
}

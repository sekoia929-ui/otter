import React, { useRef, useState } from 'react';
import { FlatList, useWindowDimensions, View, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, Logo, Txt, IconBubble } from '@/components/ui';
import { useStore } from '@/store/useStore';

const SLIDES = [
  { title: 'Track your expenses.', text: 'Log spending in seconds — even with no signal. Everything is saved on your device first.', icon: 'receipt' as const, chip: '#FFD83D' },
  { title: 'Split bills without the confusion.', text: 'Equal, exact amounts or percentages. Several payers? No problem. OTTER does the maths.', icon: 'git-compare' as const, chip: '#FFFFFF' },
  { title: 'Stay on top of shared money.', text: 'See who owes whom across friends and groups, and record settle-ups in one tap.', icon: 'people' as const, chip: '#39B982' },
];

export default function Onboarding() {
  const { width } = useWindowDimensions(); const router = useRouter(); const finish = useStore((s) => s.finishOnboarding);
  const [i, setI] = useState(0); const ref = useRef<FlatList>(null);
  const go = () => { finish(); router.replace('/welcome'); };
  const next = () => { if (i === SLIDES.length - 1) go(); else ref.current?.scrollToIndex({ index: i + 1 }); };
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#67C6FE' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'flex-end', padding: 12 }}>
        <Pressable accessibilityRole="button" onPress={go} style={{ minHeight: 44, minWidth: 64, justifyContent: 'center', alignItems: 'center' }}><Txt v="strong" color="#080808">Skip</Txt></Pressable>
      </View>
      <FlatList ref={ref} data={SLIDES} horizontal pagingEnabled showsHorizontalScrollIndicator={false} keyExtractor={(s) => s.title}
        onMomentumScrollEnd={(e) => setI(Math.round(e.nativeEvent.contentOffset.x / width))}
        renderItem={({ item }) => (
          <View style={{ width, paddingHorizontal: 28, justifyContent: 'center', gap: 22 }}>
            <View style={{ alignItems: 'center', gap: 18 }}>
              <Logo size={150} />
              <View style={{ transform: [{ rotate: '-6deg' }] }}><IconBubble name={item.icon} color={item.chip} size={56} /></View>
            </View>
            <Txt v="display" color="#080808" style={{ fontSize: 34, lineHeight: 38 }}>{item.title}</Txt>
            <Txt color="#080808" style={{ fontSize: 17, lineHeight: 24 }}>{item.text}</Txt>
          </View>
        )} />
      <View style={{ padding: 24, gap: 18 }}>
        <View style={{ flexDirection: 'row', gap: 8, justifyContent: 'center' }} accessibilityLabel={`Page ${i + 1} of ${SLIDES.length}`}>
          {SLIDES.map((_, k) => <View key={k} style={{ height: 8, width: k === i ? 28 : 8, borderRadius: 4, backgroundColor: '#080808', opacity: k === i ? 1 : 0.3 }} />)}
        </View>
        <Button title={i === SLIDES.length - 1 ? 'Get started' : 'Next'} onPress={next} icon={i === SLIDES.length - 1 ? undefined : 'arrow-forward'} />
        <Txt v="label" color="#080808" style={{ textAlign: 'center', opacity: 0.7 }}>Track. Split. Simplify.</Txt>
      </View>
    </SafeAreaView>
  );
}

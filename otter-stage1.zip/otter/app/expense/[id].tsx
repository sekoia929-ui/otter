import React from 'react';
import { Alert, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Avatar, Button, Card, EmptyState, Header, IconBubble, Pill, Row, Screen, Txt } from '@/components/ui';
import { categoryOf, PAYMENT_METHODS } from '@/lib/categories';
import { formatMoney } from '@/lib/money';
import { prettyDate } from '@/lib/dates';
import { personName, useStore } from '@/store/useStore';

export default function ExpenseDetail() {
  const { id } = useLocalSearchParams<{ id: string }>(); const router = useRouter();
  const { expenses, people, profile, deleteExpense, groups } = useStore();
  const e = expenses.find((x) => x.id === id);
  if (!e) return <Screen><Header title="Expense" /><EmptyState icon="alert-circle-outline" title="Expense not found" text="It may have been deleted." action="Go back" onAction={() => router.back()} /></Screen>;
  const cat = categoryOf(e.category); const name = (u: string) => personName(people, u, profile.name); const m = (v: number) => formatMoney(v, e.currency);
  const group = groups.find((g) => g.id === e.groupId);
  const confirmDelete = () => Alert.alert('Delete this expense?', 'This removes it from your balances too. This can’t be undone.', [{ text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: () => { deleteExpense(e.id); router.back(); } }]);
  return (
    <Screen>
      <Header title="Expense" />
      <Card style={{ alignItems: 'center', gap: 8, paddingVertical: 24 }}>
        <IconBubble name={cat.icon} color={cat.color} size={60} /><Txt v="display">{m(e.amountMinor)}</Txt><Txt v="h2">{e.description}</Txt>
        <Pill text={e.syncStatus === 'synced' ? 'SYNCED' : e.syncStatus === 'error' ? 'SYNC ERROR — TAP TO RETRY LATER' : 'SAVED ON DEVICE · WAITING TO SYNC'} tone={e.syncStatus === 'synced' ? 'green' : e.syncStatus === 'error' ? 'red' : 'yellow'} />
      </Card>
      <Card style={{ paddingVertical: 4 }}>
        <Row title="Category" right={<Txt>{cat.label}</Txt>} />
        <Row title="Date" right={<Txt>{prettyDate(e.date)}</Txt>} />
        <Row title="Payment method" right={<Txt>{PAYMENT_METHODS.find((p) => p.id === e.paymentMethod)?.label}</Txt>} />
        {group && <Row title="Group" right={<Txt>{group.emoji} {group.name}</Txt>} />}
        <Row title="Paid by" right={<Txt>{e.payments.map((p) => `${name(p.userId)} ${m(p.amountMinor)}`).join(', ')}</Txt>} last />
      </Card>
      {e.splits.length > 1 || e.splits[0]?.userId !== 'me' ? (
        <Card style={{ paddingVertical: 4 }}>
          <Txt v="label" muted style={{ paddingTop: 12 }}>Split</Txt>
          {e.splits.map((s, i) => <Row key={s.userId} last={i === e.splits.length - 1} left={<Avatar name={name(s.userId) === 'You' ? profile.name : name(s.userId)} size={36} />} title={name(s.userId)} right={<Txt v="strong">{m(s.amountMinor)}</Txt>} />)}
        </Card>) : null}
      <View style={{ gap: 10 }}>
        <Button title="Edit" icon="create-outline" variant="outline" onPress={() => router.push(`/add-expense?id=${e.id}`)} />
        <Button title="Delete" icon="trash-outline" variant="danger" onPress={confirmDelete} />
      </View>
    </Screen>
  );
}

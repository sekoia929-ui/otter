import React, { useState } from 'react';
import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { Button, Chip, EmptyState, ErrorBanner, Field, Header, Screen, Txt } from '@/components/ui';
import { groupSchema, firstError } from '@/lib/validation';
import { useStore } from '@/store/useStore';

const EMOJIS = ['🏠', '🏔️', '✈️', '🍕', '🎉', '🛒', '🚗', '💼'];
export default function NewGroup() {
  const router = useRouter(); const { people, addGroup } = useStore();
  const friends = people.filter((p) => p.status === 'friend');
  const [name, setName] = useState(''); const [emoji, setEmoji] = useState('🏠'); const [ids, setIds] = useState<string[]>([]); const [error, setError] = useState<string | null>(null);
  const create = () => {
    const err = firstError(groupSchema, { name, memberIds: ids }); if (err) return setError(err);
    const id = addGroup(name.trim(), emoji, ids); router.replace(`/group/${id}`);
  };
  return (
    <Screen>
      <Header title="New group" />
      {error && <ErrorBanner message={error} />}
      <Field label="Group name" value={name} onChangeText={setName} placeholder="e.g. Ski weekend" maxLength={40} />
      <Txt v="label" muted>Icon</Txt>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{EMOJIS.map((e) => <Chip key={e} label={e} selected={emoji === e} onPress={() => setEmoji(e)} />)}</View>
      <Txt v="label" muted>Add friends</Txt>
      {friends.length === 0 ? <EmptyState icon="person-add-outline" title="No friends yet" text="Add a friend first, then create a group with them." action="Add friend" onAction={() => router.replace('/friends/add')} /> : (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{friends.map((f) => <Chip key={f.id} label={f.name} icon={ids.includes(f.id) ? 'checkmark' : undefined} selected={ids.includes(f.id)} onPress={() => setIds(ids.includes(f.id) ? ids.filter((x) => x !== f.id) : [...ids, f.id])} />)}</View>)}
      <Button title="Create group" variant="brand" onPress={create} />
    </Screen>
  );
}

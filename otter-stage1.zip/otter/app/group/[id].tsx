import React, { useMemo } from 'react';
import { View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ExpenseRow } from '@/components/ExpenseRow';
import { Avatar, Button, Card, EmptyState, Header, IconBubble, OfflineBanner, Row, Screen, SectionTitle, Txt } from '@/components/ui';
import { netBalances, simplifyDebts } from '@/lib/balances';
import { groupExpenses, groupSettlements, sortNewest, sum } from '@/lib/derive';
import { prettyDate } from '@/lib/dates';
import { formatMoney } from '@/lib/money';
import { ME } from '@/lib/types';
import { personName, useStore } from '@/store/useStore';
import { useTheme } from '@/theme/ThemeProvider';

export default function GroupDetail() {
  const { id } = useLocalSearchParams<{ id: string }>(); const router = useRouter(); const { colors } = useTheme();
  const { groups, expenses, settlements, people, profile } = useStore();
  const g = groups.find((x) => x.id === id);
  const d = useMemo(() => {
    if (!g) return null;
    const ex = groupExpenses(expenses, g.id).sort(sortNewest); const st = groupSettlements(settlements, g.id);
    const net = netBalances(ex, st);
    return { ex, st, net, plan: simplifyDebts(net), total: sum(ex.map((e) => e.amountMinor)) };
  }, [g, expenses, settlements]);
  if (!g || !d) return <Screen><Header title="Group" /><EmptyState icon="alert-circle-outline" title="Group not found" text="It may have been removed." action="Go back" onAction={() => router.back()} /></Screen>;
  const name = (u: string) => personName(people, u, profile.name); const m = (v: number) => formatMoney(v, 'USD');
  const mine = d.net[ME] ?? 0;
  return (
    <Screen>
      <Header title={`${g.emoji} ${g.name}`} />
      <OfflineBanner />
      <Card soft style={{ gap: 4 }}>
        <Txt v="label" muted>Your balance</Txt>
        <Txt v="display" color={mine === 0 ? colors.text : mine > 0 ? colors.positive : colors.negative}>{mine === 0 ? 'Settled up' : m(Math.abs(mine))}</Txt>
        <Txt muted>{mine > 0 ? 'The group owes you' : mine < 0 ? 'You owe the group' : 'Nothing to pay'} · {m(d.total)} spent in total</Txt>
      </Card>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Button title="Add expense" icon="add" variant="brand" style={{ flex: 1, paddingHorizontal: 12 }} onPress={() => router.push(`/add-expense?groupId=${g.id}`)} />
        <Button title="Settle up" icon="swap-horizontal" variant="outline" style={{ flex: 1, paddingHorizontal: 12 }} onPress={() => router.push(`/settle?groupId=${g.id}`)} />
      </View>
      <SectionTitle title="Who owes whom" />
      <Card style={{ paddingVertical: 4 }}>
        {d.plan.length === 0 ? <EmptyState icon="checkmark-circle-outline" title="All settled" text="Nobody owes anything in this group." /> :
          d.plan.map((p, i) => (
            <Row key={i} last={i === d.plan.length - 1} left={<Avatar name={name(p.from) === 'You' ? profile.name : name(p.from)} />} title={`${name(p.from)} → ${name(p.to)}`} subtitle={m(p.amount)}
              right={<Button title="Record" variant="outline" style={{ minHeight: 44, paddingHorizontal: 14 }} onPress={() => router.push(`/settle?groupId=${g.id}&from=${p.from}&to=${p.to}&amount=${p.amount}`)} />} />))}
      </Card>
      <SectionTitle title="Members" />
      <Card style={{ paddingVertical: 4 }}>
        {g.memberIds.map((u, i) => { const b = d.net[u] ?? 0; return <Row key={u} last={i === g.memberIds.length - 1} left={<Avatar name={name(u) === 'You' ? profile.name : name(u)} />} title={name(u)} subtitle={b === 0 ? 'Settled up' : b > 0 ? 'Is owed' : 'Owes'} right={<Txt v="strong" color={b > 0 ? colors.positive : b < 0 ? colors.negative : colors.muted}>{b === 0 ? '—' : m(Math.abs(b))}</Txt>} />; })}
      </Card>
      <SectionTitle title="Expenses" />
      <Card style={{ paddingVertical: 4 }}>{d.ex.length === 0 ? <EmptyState icon="receipt-outline" title="No expenses yet" text="Add the first shared expense." /> : d.ex.map((e, i) => <ExpenseRow key={e.id} e={e} last={i === d.ex.length - 1} />)}</Card>
      {d.st.length > 0 && (<><SectionTitle title="Settlements" /><Card style={{ paddingVertical: 4 }}>{d.st.map((s, i) => <Row key={s.id} last={i === d.st.length - 1} left={<IconBubble name="swap-horizontal" color="#39B982" />} title={`${name(s.fromId)} paid ${name(s.toId)}`} subtitle={`${prettyDate(s.date)}${s.note ? ' · ' + s.note : ''}`} right={<Txt v="strong">{m(s.amountMinor)}</Txt>} />)}</Card></>)}
    </Screen>
  );
}

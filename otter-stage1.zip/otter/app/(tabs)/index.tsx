import React, { useMemo } from 'react';
import { Pressable, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Bars } from '@/components/charts';
import { ExpenseRow } from '@/components/ExpenseRow';
import { Card, EmptyState, IconBubble, Logo, OfflineBanner, Screen, SectionTitle, Txt } from '@/components/ui';
import { monthRange } from '@/lib/dates';
import { last7Days, pctChange, sortNewest, spendInRange } from '@/lib/derive';
import { myTotals } from '@/lib/balances';
import { formatMoney } from '@/lib/money';
import { ME } from '@/lib/types';
import { useStore } from '@/store/useStore';
import { useTheme } from '@/theme/ThemeProvider';

export default function Home() {
  const router = useRouter(); const { colors } = useTheme();
  const { expenses, settlements, people, profile, settings } = useStore();
  const cur = settings.currency; const m = (v: number) => formatMoney(v, cur);
  const d = useMemo(() => {
    const a = monthRange(0), b = monthRange(-1);
    const total = spendInRange(expenses, a.start, a.end);
    const prev = spendInRange(expenses, b.start, b.end);
    const personal = spendInRange(expenses, a.start, a.end, true);
    const t = myTotals(expenses, settlements, ME, people.filter((p) => p.status === 'friend').map((p) => p.id));
    return { total, prev, personal, ...t, label: a.label, week: last7Days(expenses), recent: [...expenses].sort(sortNewest).slice(0, 5) };
  }, [expenses, settlements, people]);
  const change = pctChange(d.total, d.prev);
  const actions = [
    { label: 'Add Expense', icon: 'add-circle' as const, color: '#FFD83D', go: () => router.push('/add-expense') },
    { label: 'Split Bill', icon: 'git-compare' as const, color: '#67C6FE', go: () => router.push('/add-expense?mode=shared') },
    { label: 'Groups', icon: 'people' as const, color: '#39B982', go: () => router.push('/groups') },
  ];
  return (
    <Screen>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <View><Txt muted v="small">Hello,</Txt><Txt v="title">{profile.name.split(' ')[0]}</Txt></View>
        <Logo size={48} />
      </View>
      <OfflineBanner />
      <Card style={{ backgroundColor: colors.primary, borderColor: '#080808', borderWidth: 2, gap: 6 }}>
        <Txt v="label" color="#080808">Spent in {d.label}</Txt>
        <Txt v="display" color="#080808" accessibilityLabel={`Total spent this month ${m(d.total)}`}>{m(d.total)}</Txt>
        {change !== null && <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name={change > 0 ? 'trending-up' : 'trending-down'} size={18} color="#080808" /><Txt v="strong" color="#080808">{Math.abs(change)}% {change > 0 ? 'more' : 'less'} than last month</Txt></View>}
      </Card>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        {[{ l: 'Personal', v: m(d.personal), c: colors.text }, { l: 'You owe', v: m(d.owe), c: d.owe > 0 ? colors.negative : colors.text }, { l: 'Owed to you', v: m(d.owed), c: d.owed > 0 ? colors.positive : colors.text }].map((s) => (
          <Card key={s.l} style={{ flex: 1, padding: 12, gap: 4 }}><Txt v="small" muted>{s.l}</Txt><Txt v="strong" color={s.c} numberOfLines={1} adjustsFontSizeToFit>{s.v}</Txt></Card>
        ))}
      </View>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        {actions.map((a) => (
          <Pressable key={a.label} accessibilityRole="button" onPress={a.go} style={({ pressed }) => ({ flex: 1, alignItems: 'center', gap: 8, paddingVertical: 14, borderRadius: 22, borderWidth: 1.5, borderColor: colors.border, opacity: pressed ? 0.8 : 1, minHeight: 44 })}>
            <IconBubble name={a.icon} color={a.color} /><Txt v="small" style={{ fontWeight: '700' }}>{a.label}</Txt>
          </Pressable>
        ))}
      </View>
      <SectionTitle title="Last 7 days" action="Statistics" onAction={() => router.push('/stats')} />
      <Card><Bars data={d.week} onFormat={m} /></Card>
      <SectionTitle title="Recent transactions" action="See all" onAction={() => router.push('/activity')} />
      <Card style={{ paddingVertical: 4 }}>
        {d.recent.length === 0 ? <EmptyState icon="receipt-outline" title="No expenses yet" text="Tap the + button to add your first expense." /> : d.recent.map((e, i) => <ExpenseRow key={e.id} e={e} last={i === d.recent.length - 1} />)}
      </Card>
    </Screen>
  );
}

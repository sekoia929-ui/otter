import { Redirect } from 'expo-router';
// The centre tab is a button (see _layout). If someone lands here, open the real screen.
export default function AddTab() { return <Redirect href="/add-expense" />; }

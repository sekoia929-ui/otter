import React from 'react';
import { Alert, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Avatar, Card, ComingSoon, IconBubble, Row, Screen, Txt } from '@/components/ui';
import { useStore } from '@/store/useStore';

export default function Profile() {
  const router = useRouter(); const { profile, people, signOut, simulateOffline } = useStore();
  const pending = people.filter((p) => p.status === 'incoming').length;
  return (
    <Screen>
      <Txt v="title">Profile</Txt>
      <Card style={{ alignItems: 'center', gap: 8, paddingVertical: 24 }}>
        <Avatar name={profile.name} size={84} /><Txt v="h2">{profile.name}</Txt><Txt muted>{profile.email}</Txt>
        <Txt v="small" muted>{simulateOffline ? 'Offline preview on' : 'All changes saved on this device'}</Txt>
      </Card>
      <Card style={{ paddingVertical: 4 }}>
        <Row left={<IconBubble name="stats-chart" color="#FFD83D" />} title="Statistics" subtitle="Trends & category breakdown" onPress={() => router.push('/stats')} right={<Txt muted>›</Txt>} />
        <Row left={<IconBubble name="people" color="#67C6FE" />} title="Friends" subtitle={pending ? `${pending} request waiting` : 'List, requests & balances'} onPress={() => router.push('/groups')} right={<Txt muted>›</Txt>} />
        <Row left={<IconBubble name="wallet" color="#B7A4F5" />} title="Wallet & payments" subtitle="Not live yet" onPress={() => router.push('/wallet')} right={<ComingSoon />} />
        <Row left={<IconBubble name="settings" color="#39B982" />} title="Settings" subtitle="Currency, theme, export, account" onPress={() => router.push('/settings')} right={<Txt muted>›</Txt>} last />
      </Card>
      <Card style={{ paddingVertical: 4 }}>
        <Row left={<IconBubble name="log-out" color="#F59B7A" />} title="Sign out" onPress={() => Alert.alert('Sign out?', 'Your data stays saved on this device.', [{ text: 'Cancel', style: 'cancel' }, { text: 'Sign out', style: 'destructive', onPress: () => { signOut(); router.replace('/welcome'); } }])} last />
      </Card>
      <Txt v="small" muted style={{ textAlign: 'center' }}>OTTER 0.1.0 · Track. Split. Simplify.</Txt>
    </Screen>
  );
}

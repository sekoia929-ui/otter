import React, { useMemo, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { useRouter } from 'expo-router';
import { ExpenseRow } from '@/components/ExpenseRow';
import { Card, Chip, EmptyState, IconBubble, OfflineBanner, Row, Screen, Segmented, Txt } from '@/components/ui';
import { CATEGORIES, CategoryId } from '@/lib/categories';
import { inRange, monthRange, prettyDate } from '@/lib/dates';
import { sortNewest } from '@/lib/derive';
import { formatMoney } from '@/lib/money';
import { ME, isShared } from '@/lib/types';
import { personName, useStore } from '@/store/useStore';

type When = 'all' | 'week' | 'month' | 'last';
export default function Activity() {
  const router = useRouter();
  const { expenses, settlements, people, profile } = useStore();
  const [cat, setCat] = useState<CategoryId | 'all'>('all'); const [when, setWhen] = useState<When>('all'); const [kind, setKind] = useState<'all' | 'personal' | 'shared'>('all');
  const rows = useMemo(() => {
    const now = new Date(); const wk = new Date(); wk.setDate(now.getDate() - 7);
    const range = when === 'week' ? { a: wk, b: new Date(Date.now() + 864e5) } : when === 'month' ? { a: monthRange(0).start, b: monthRange(0).end } : when === 'last' ? { a: monthRange(-1).start, b: monthRange(-1).end } : null;
    const ex = expenses.filter((e) => (cat === 'all' || e.category === cat) && (!range || inRange(e.date, range.a, range.b)) && (kind === 'all' || (kind === 'shared') === isShared(e)));
    const st = cat === 'all' && kind !== 'personal' ? settlements.filter((s) => !range || inRange(s.date, range.a, range.b)) : [];
    return [...ex.map((e) => ({ t: 'e' as const, date: e.date, e })), ...st.map((s) => ({ t: 's' as const, date: s.date, s }))].sort((a, b) => b.date.localeCompare(a.date));
  }, [expenses, settlements, cat, when, kind]);
  return (
    <Screen>
      <Txt v="title">Activity</Txt>
      <OfflineBanner />
      <Segmented value={kind} onChange={setKind} options={[{ id: 'all', label: 'All' }, { id: 'personal', label: 'Personal' }, { id: 'shared', label: 'Shared' }]} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        {([['all', 'All time'], ['week', 'Last 7 days'], ['month', 'This month'], ['last', 'Last month']] as [When, string][]).map(([id, l]) => <Chip key={id} label={l} selected={when === id} onPress={() => setWhen(id)} />)}
      </ScrollView>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        <Chip label="All categories" selected={cat === 'all'} onPress={() => setCat('all')} />
        {CATEGORIES.map((c) => <Chip key={c.id} label={c.label} icon={c.icon} color={c.color} selected={cat === c.id} onPress={() => setCat(c.id)} />)}
      </ScrollView>
      <Card style={{ paddingVertical: 4 }}>
        {rows.length === 0 ? <EmptyState icon="search-outline" title="Nothing here" text="No transactions match these filters." action="Clear filters" onAction={() => { setCat('all'); setWhen('all'); setKind('all'); }} /> :
          rows.map((r, i) => r.t === 'e' ? <ExpenseRow key={r.e.id} e={r.e} last={i === rows.length - 1} /> : (
            <Row key={r.s.id} last={i === rows.length - 1} left={<IconBubble name="swap-horizontal" color="#39B982" />}
              title={`${personName(people, r.s.fromId, profile.name)} paid ${personName(people, r.s.toId, profile.name).replace('You', 'you')}`} subtitle={`${prettyDate(r.s.date)} · Settlement${r.s.note ? ' · ' + r.s.note : ''}`}
              right={<Txt v="strong">{formatMoney(r.s.amountMinor, r.s.currency)}</Txt>} />
          ))}
      </Card>
      <Txt v="small" muted style={{ textAlign: 'center' }}>{rows.length} item{rows.length === 1 ? '' : 's'} · Saved on this device</Txt>
    </Screen>
  );
}

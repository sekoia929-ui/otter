import React from 'react';
import { Pressable, View } from 'react-native';
import { Redirect, Tabs, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/theme/ThemeProvider';
import { useStore } from '@/store/useStore';

type IconName = React.ComponentProps<typeof Ionicons>['name'];
const tab = (focused: IconName, idle: IconName) => ({ color, focused: f }: { color: any; focused: boolean }) => <Ionicons name={f ? focused : idle} size={24} color={color} />;

function AddButton() {
  const router = useRouter(); const { colors } = useTheme();
  return (
    <View style={{ flex: 1, alignItems: 'center' }}>
      <Pressable accessibilityRole="button" accessibilityLabel="Add expense" onPress={() => router.push('/add-expense')}
        style={({ pressed }) => ({ marginTop: -22, width: 62, height: 62, borderRadius: 31, backgroundColor: colors.primary, borderWidth: 3, borderColor: '#080808', alignItems: 'center', justifyContent: 'center', transform: [{ scale: pressed ? 0.95 : 1 }] })}>
        <Ionicons name="add" size={34} color="#080808" />
      </Pressable>
    </View>
  );
}

export default function TabsLayout() {
  const { colors } = useTheme(); const signedIn = useStore((s) => s.signedIn);
  if (!signedIn) return <Redirect href="/welcome" />;
  return (
    <Tabs screenOptions={{
      headerShown: false, tabBarActiveTintColor: colors.text, tabBarInactiveTintColor: colors.muted,
      tabBarStyle: { backgroundColor: colors.bg, borderTopColor: colors.border, borderTopWidth: 1.5, height: 68 },
      tabBarLabelStyle: { fontSize: 11, fontWeight: '700' },
    }}>
      <Tabs.Screen name="index" options={{ title: 'Home', tabBarIcon: tab('home', 'home-outline') }} />
      <Tabs.Screen name="activity" options={{ title: 'Activity', tabBarIcon: tab('receipt', 'receipt-outline') }} />
      <Tabs.Screen name="add" options={{ title: 'Add', tabBarButton: () => <AddButton /> }} />
      <Tabs.Screen name="groups" options={{ title: 'Groups', tabBarIcon: tab('people', 'people-outline') }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile', tabBarIcon: tab('person-circle', 'person-circle-outline') }} />
    </Tabs>
  );
}

import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { Avatar, Button, Card, EmptyState, Field, OfflineBanner, Pill, Row, Screen, SectionTitle, Segmented, Txt } from '@/components/ui';
import { netBalances, pairBalance } from '@/lib/balances';
import { groupExpenses, groupSettlements } from '@/lib/derive';
import { formatMoney } from '@/lib/money';
import { ME } from '@/lib/types';
import { useStore } from '@/store/useStore';
import { useTheme } from '@/theme/ThemeProvider';

export function BalanceText({ amount, currency }: { amount: number; currency: string }) {
  const { colors } = useTheme();
  if (amount === 0) return <Txt v="small" muted>settled up</Txt>;
  return (<View style={{ alignItems: 'flex-end' }}><Txt v="small" muted>{amount > 0 ? 'owes you' : 'you owe'}</Txt><Txt v="strong" color={amount > 0 ? colors.positive : colors.negative}>{formatMoney(Math.abs(amount), currency)}</Txt></View>);
}

export default function Groups() {
  const router = useRouter(); const { colors } = useTheme();
  const { groups, expenses, settlements, people, settings } = useStore();
  const [tab, setTab] = useState<'groups' | 'friends'>('groups'); const [q, setQ] = useState('');
  const friends = people.filter((p) => p.status === 'friend');
  const requests = people.filter((p) => p.status === 'incoming');
  const shown = useMemo(() => friends.filter((f) => f.name.toLowerCase().includes(q.trim().toLowerCase()) || f.email.toLowerCase().includes(q.trim().toLowerCase())), [friends, q]);
  return (
    <Screen>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Txt v="title">{tab === 'groups' ? 'Groups' : 'Friends'}</Txt>
        <Button title={tab === 'groups' ? 'New group' : 'Add friend'} icon="add" variant="brand" style={{ minHeight: 44, paddingHorizontal: 16 }} onPress={() => router.push(tab === 'groups' ? '/group/new' : '/friends/add')} />
      </View>
      <OfflineBanner />
      <Segmented value={tab} onChange={setTab} options={[{ id: 'groups', label: 'Groups' }, { id: 'friends', label: `Friends${requests.length ? ` · ${requests.length} new` : ''}` }]} />
      {tab === 'groups' ? (
        groups.length === 0 ? <EmptyState icon="people-outline" title="No groups yet" text="Create a group for a trip, flat or dinner club." action="Create group" onAction={() => router.push('/group/new')} /> :
        groups.map((g) => {
          const mine = netBalances(groupExpenses(expenses, g.id), groupSettlements(settlements, g.id))[ME] ?? 0;
          return (
            <Card key={g.id} onPress={() => router.push(`/group/${g.id}`)} style={{ gap: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                <View style={{ width: 52, height: 52, borderRadius: 18, backgroundColor: colors.soft, alignItems: 'center', justifyContent: 'center' }}><Txt style={{ fontSize: 26 }}>{g.emoji}</Txt></View>
                <View style={{ flex: 1 }}><Txt v="h2">{g.name}</Txt><Txt v="small" muted>{g.memberIds.length} members</Txt></View>
                <BalanceText amount={mine} currency={settings.currency} />
              </View>
            </Card>
          );
        })
      ) : (<>
        {requests.length > 0 && <Card soft style={{ gap: 4 }}><Txt v="strong">{requests.length} friend request{requests.length > 1 ? 's' : ''} waiting</Txt>{requests.map((r) => <Row key={r.id} left={<Avatar name={r.name} />} title={r.name} subtitle="Wants to be friends" onPress={() => router.push(`/friends/${r.id}`)} last />)}</Card>}
        <Field value={q} onChangeText={setQ} placeholder="Search friends" accessibilityLabel="Search friends" autoCapitalize="none" />
        <Card style={{ paddingVertical: 4 }}>
          {shown.length === 0 ? <EmptyState icon="person-add-outline" title={q ? 'No match' : 'No friends yet'} text={q ? 'Try a different name or email.' : 'Send a friend request to start splitting.'} action={q ? undefined : 'Add friend'} onAction={() => router.push('/friends/add')} /> :
            shown.map((f, i) => <Row key={f.id} last={i === shown.length - 1} left={<Avatar name={f.name} />} title={f.name} subtitle={f.email} onPress={() => router.push(`/friends/${f.id}`)} right={<BalanceText amount={pairBalance(expenses, settlements, ME, f.id)} currency={settings.currency} />} />)}
        </Card>
        {people.some((p) => p.status === 'outgoing') && <><SectionTitle title="Sent requests" />{people.filter((p) => p.status === 'outgoing').map((p) => <Card key={p.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}><Avatar name={p.name} /><View style={{ flex: 1 }}><Txt v="strong">{p.name}</Txt><Txt v="small" muted>{p.email}</Txt></View><Pill text="PENDING" tone="yellow" /></Card>)}</>}
      </>)}
    </Screen>
  );
}

import React, { useState } from 'react';
import { Alert, Share } from 'react-native';
import { useRouter } from 'expo-router';
import { Button, Card, Chip, Field, Header, NeedsInternet, ComingSoon, Row, Screen, Segmented, SectionTitle, ToggleRow, Txt } from '@/components/ui';
import { CURRENCIES } from '@/lib/money';
import { emailSchema } from '@/lib/validation';
import { useStore } from '@/store/useStore';
import { View } from 'react-native';

export default function Settings() {
  const router = useRouter();
  const { profile, settings, setProfile, setSettings, setNotification, expenses, signOut, simulateOffline, toggleOffline } = useStore();
  const [name, setName] = useState(profile.name); const [email, setEmail] = useState(profile.email); const [err, setErr] = useState<string | null>(null);
  const saveProfile = () => {
    const r = emailSchema.safeParse(email); if (!r.success || name.trim().length < 2) return setErr(!r.success ? r.error.issues[0].message : 'Enter your name');
    setErr(null); setProfile({ name: name.trim(), email: r.data }); Alert.alert('Saved', 'Profile updated.');
  };
  const exportCsv = async () => {
    const rows = [['date', 'description', 'category', 'amount', 'currency', 'payment_method'], ...expenses.map((e) => [e.date.slice(0, 10), `"${e.description.replace(/"/g, '""')}"`, e.category, (e.amountMinor / 100).toFixed(2), e.currency, e.paymentMethod])];
    await Share.share({ title: 'OTTER expenses', message: rows.map((r) => r.join(',')).join('\n') });
  };
  return (
    <Screen>
      <Header title="Settings" />
      <SectionTitle title="Profile" />
      <Card style={{ gap: 12 }}>
        <Field label="Name" value={name} onChangeText={setName} /><Field label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" error={err} />
        <Button title="Save profile" variant="outline" onPress={saveProfile} />
      </Card>
      <SectionTitle title="Currency" />
      <Card style={{ gap: 10 }}>
        <Txt v="small" muted>Used for totals and new expenses. Amounts are not converted between currencies.</Txt>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{CURRENCIES.map((c) => <Chip key={c} label={c} selected={settings.currency === c} onPress={() => setSettings({ currency: c })} />)}</View>
      </Card>
      <SectionTitle title="Appearance" />
      <Segmented value={settings.theme} onChange={(t) => setSettings({ theme: t })} options={[{ id: 'system', label: 'System' }, { id: 'light', label: 'Light' }, { id: 'dark', label: 'Dark' }]} />
      <SectionTitle title="Notifications" />
      <Card style={{ paddingVertical: 4 }}>
        <ToggleRow title="Reminders" subtitle="Nudges to log expenses" value={settings.notifications.reminders} onChange={(v) => setNotification('reminders', v)} />
        <ToggleRow title="Friend requests" value={settings.notifications.friendRequests} onChange={(v) => setNotification('friendRequests', v)} />
        <ToggleRow title="Settlements" value={settings.notifications.settlements} onChange={(v) => setNotification('settlements', v)} />
      </Card>
      <SectionTitle title="Data" />
      <Card style={{ paddingVertical: 4 }}>
        <Row title="Export expenses (CSV)" subtitle="Works offline" onPress={exportCsv} right={<Txt muted>›</Txt>} />
        <ToggleRow title="Preview offline mode" subtitle="Demo only: shows how OTTER behaves with no internet" value={simulateOffline} onChange={toggleOffline} />
      </Card>
      <SectionTitle title="Account" />
      <Card style={{ paddingVertical: 4 }}>
        <Row title="Change password" subtitle="Needs internet" right={<NeedsInternet />} onPress={() => Alert.alert('Coming in Stage 5', 'Password changes are handled by Supabase Auth.')} />
        <Row title="Delete account" subtitle="Removes cloud data" right={<ComingSoon />} last />
      </Card>
      <Button title="Sign out" variant="danger" onPress={() => { signOut(); router.replace('/welcome'); }} />
    </Screen>
  );
}

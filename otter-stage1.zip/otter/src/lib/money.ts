// RULE: money is ALWAYS an integer in minor units (cents). Never use floats for maths.
const SYMBOLS: Record<string, string> = { USD: '$', EUR: '€', GBP: '£', INR: '₹', CHF: 'CHF ', AED: 'AED ', UZS: 'soʻm ' };
export const CURRENCIES = Object.keys(SYMBOLS);

export function formatMoney(minor: number, currency = 'USD', opts: { sign?: boolean } = {}): string {
  const abs = Math.abs(Math.round(minor));
  const whole = Math.floor(abs / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const cents = (abs % 100).toString().padStart(2, '0');
  const sign = minor < 0 ? '-' : opts.sign && minor > 0 ? '+' : '';
  return `${sign}${SYMBOLS[currency] ?? currency + ' '}${whole}.${cents}`;
}

/** "12.5" -> 1250. Returns null for invalid / empty input. */
export function parseMinor(input: string): number | null {
  const clean = input.trim().replace(',', '.');
  if (!/^\d*\.?\d{0,2}$/.test(clean) || clean === '' || clean === '.') return null;
  const [w, c = ''] = clean.split('.');
  const v = parseInt(w || '0', 10) * 100 + parseInt(c.padEnd(2, '0') || '0', 10);
  return Number.isFinite(v) ? v : null;
}
export const minorToInput = (m: number) => (m / 100).toFixed(2);

import { z } from 'zod';

export const emailSchema = z.string().trim().email('Enter a valid email address');
export const loginSchema = z.object({ email: emailSchema, password: z.string().min(6, 'At least 6 characters') });
export const signUpSchema = loginSchema.extend({ name: z.string().trim().min(2, 'Enter your name') });
export const groupSchema = z.object({
  name: z.string().trim().min(2, 'Give the group a name').max(40),
  memberIds: z.array(z.string()).min(1, 'Pick at least one friend'),
});

export const expenseSchema = z.object({
  description: z.string().trim().min(1, 'Add a short description').max(80),
  amountMinor: z.number().int().positive('Enter an amount above 0'),
  date: z.date(),
});

/** Returns the first error message, or null if valid. */
export function firstError<T>(schema: z.ZodType<T>, value: unknown): string | null {
  const r = schema.safeParse(value);
  return r.success ? null : r.error.issues[0]?.message ?? 'Invalid input';
}

export type CategoryId = 'food' | 'transport' | 'shopping' | 'housing' | 'entertainment' | 'healthcare' | 'education' | 'others';
export type PaymentMethod = 'cash' | 'card' | 'bank' | 'mobile';
type IconName = React.ComponentProps<typeof import('@expo/vector-icons').Ionicons>['name'];

export const CATEGORIES: { id: CategoryId; label: string; icon: IconName; color: string }[] = [
  { id: 'food', label: 'Food', icon: 'restaurant', color: '#FFD83D' },
  { id: 'transport', label: 'Transport', icon: 'car', color: '#67C6FE' },
  { id: 'shopping', label: 'Shopping', icon: 'bag', color: '#F7A8C4' },
  { id: 'housing', label: 'Housing', icon: 'home', color: '#39B982' },
  { id: 'entertainment', label: 'Entertainment', icon: 'film', color: '#B7A4F5' },
  { id: 'healthcare', label: 'Healthcare', icon: 'medkit', color: '#F59B7A' },
  { id: 'education', label: 'Education', icon: 'school', color: '#7FA8F8' },
  { id: 'others', label: 'Others', icon: 'ellipsis-horizontal', color: '#B4BEC6' },
];
export const categoryOf = (id: CategoryId) => CATEGORIES.find((c) => c.id === id) ?? CATEGORIES[7];

export const PAYMENT_METHODS: { id: PaymentMethod; label: string; icon: IconName }[] = [
  { id: 'cash', label: 'Cash', icon: 'cash-outline' },
  { id: 'card', label: 'Card', icon: 'card-outline' },
  { id: 'bank', label: 'Bank', icon: 'business-outline' },
  { id: 'mobile', label: 'Mobile pay', icon: 'phone-portrait-outline' },
];

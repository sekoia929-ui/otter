import type { Line } from './types';

/** Equal split. Leftover cents go to the first people so the total is always exact. */
export function splitEqual(total: number, ids: string[]): Line[] {
  if (ids.length === 0) return [];
  const base = Math.floor(total / ids.length);
  let rest = total - base * ids.length;
  return ids.map((userId) => ({ userId, amountMinor: base + (rest-- > 0 ? 1 : 0) }));
}

/** Percentage split. `pct` is a map of id -> percent (e.g. 33.5). Must add up to 100. */
export function splitPercent(total: number, pct: Record<string, number>): Line[] {
  const ids = Object.keys(pct);
  const lines = ids.map((userId) => ({ userId, amountMinor: Math.floor((total * pct[userId]) / 100) }));
  let rest = total - lines.reduce((s, l) => s + l.amountMinor, 0);
  for (let i = 0; rest > 0 && lines.length > 0; i = (i + 1) % lines.length, rest--) lines[i].amountMinor += 1;
  return lines;
}

export const sumLines = (lines: Line[]) => lines.reduce((s, l) => s + l.amountMinor, 0);

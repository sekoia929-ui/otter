export const daysAgo = (n: number, hour = 12) => {
  const d = new Date(); d.setDate(d.getDate() - n); d.setHours(hour, 0, 0, 0); return d.toISOString();
};
/** Local YYYY-MM-DD (for the date input). */
export const toDateInput = (d: Date | string) => {
  const x = typeof d === 'string' ? new Date(d) : d;
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
};
export const fromDateInput = (s: string): Date | null => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const d = new Date(`${s}T12:00:00`); return isNaN(d.getTime()) ? null : d;
};
export const monthRange = (offset = 0) => {
  const n = new Date();
  const start = new Date(n.getFullYear(), n.getMonth() + offset, 1);
  const end = new Date(n.getFullYear(), n.getMonth() + offset + 1, 1);
  return { start, end, label: start.toLocaleDateString(undefined, { month: 'long', year: 'numeric' }) };
};
export const inRange = (isoStr: string, a: Date, b: Date) => { const t = new Date(isoStr).getTime(); return t >= a.getTime() && t < b.getTime(); };
export const startOfWeek = (d = new Date()) => { const x = new Date(d); const day = (x.getDay() + 6) % 7; x.setDate(x.getDate() - day); x.setHours(0, 0, 0, 0); return x; };
export const prettyDate = (s: string) => {
  const d = new Date(s); const t = new Date();
  const same = (a: Date, b: Date) => a.toDateString() === b.toDateString();
  const y = new Date(); y.setDate(t.getDate() - 1);
  if (same(d, t)) return 'Today'; if (same(d, y)) return 'Yesterday';
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
};

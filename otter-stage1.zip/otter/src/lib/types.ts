import type { CategoryId, PaymentMethod } from './categories';

export const ME = 'me'; // id of the signed-in user in the local data

export type SyncStatus = 'synced' | 'pending' | 'error'; // used by Stage 4 (sync queue)

export type Person = {
  id: string;
  name: string;
  email: string;
  /** friend = accepted, incoming = they asked you, outgoing = you asked them */
  status: 'friend' | 'incoming' | 'outgoing';
};

export type Group = { id: string; name: string; emoji: string; memberIds: string[]; createdAt: string };

export type Line = { userId: string; amountMinor: number };

export type Expense = {
  id: string;
  description: string;
  amountMinor: number;
  currency: string;
  category: CategoryId;
  date: string; // ISO
  paymentMethod: PaymentMethod;
  /** null = personal OR a split between friends outside a group (see `splits`) */
  groupId: string | null;
  /** WHO PAID (can be several people). Sums to amountMinor. */
  payments: Line[];
  /** WHO OWES (each person's share). Sums to amountMinor. Personal = only me. */
  splits: Line[];
  createdAt: string;
  updatedAt: string;
  syncStatus: SyncStatus;
};

/** A settlement is a record that `fromId` paid `toId` back. It is NOT an expense. */
export type Settlement = {
  id: string; fromId: string; toId: string; amountMinor: number; currency: string;
  groupId: string | null; date: string; note: string; syncStatus: SyncStatus;
};

export type Debt = { from: string; to: string; amount: number };

export const isShared = (e: Expense) => e.splits.some((s) => s.userId !== ME) || e.payments.some((p) => p.userId !== ME);

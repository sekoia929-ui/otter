import { Debt, Expense, Settlement } from './types';

/** Turn ONE expense into pairwise debts (who owes whom). Integer-safe. */
export function expenseDebts(e: Pick<Expense, 'payments' | 'splits'>): Debt[] {
  const net = new Map<string, number>(); // positive = paid more than their share
  e.payments.forEach((p) => net.set(p.userId, (net.get(p.userId) ?? 0) + p.amountMinor));
  e.splits.forEach((s) => net.set(s.userId, (net.get(s.userId) ?? 0) - s.amountMinor));
  const debtors = [...net].filter(([, v]) => v < 0);
  const creditors = [...net].filter(([, v]) => v > 0);
  const totalCredit = creditors.reduce((s, [, v]) => s + v, 0);
  const out: Debt[] = [];
  for (const [d, dv] of debtors) {
    let remaining = -dv;
    creditors.forEach(([c, cv], i) => {
      const last = i === creditors.length - 1;
      const share = last ? remaining : Math.floor((-dv * cv) / totalCredit);
      remaining -= share;
      if (share > 0) out.push({ from: d, to: c, amount: share });
    });
  }
  return out;
}

/** Net position per person across expenses + settlements. Positive = is owed money. */
export function netBalances(expenses: Expense[], settlements: Settlement[]): Record<string, number> {
  const net: Record<string, number> = {};
  const add = (id: string, v: number) => (net[id] = (net[id] ?? 0) + v);
  for (const e of expenses) {
    e.payments.forEach((p) => add(p.userId, p.amountMinor));
    e.splits.forEach((s) => add(s.userId, -s.amountMinor));
  }
  for (const s of settlements) { add(s.fromId, s.amountMinor); add(s.toId, -s.amountMinor); }
  return net;
}

/** Fewest payments that settle everyone up (greedy). */
export function simplifyDebts(net: Record<string, number>): Debt[] {
  const give = Object.entries(net).filter(([, v]) => v < 0).map(([id, v]) => ({ id, v: -v })).sort((a, b) => b.v - a.v);
  const get = Object.entries(net).filter(([, v]) => v > 0).map(([id, v]) => ({ id, v })).sort((a, b) => b.v - a.v);
  const out: Debt[] = [];
  let i = 0, j = 0;
  while (i < give.length && j < get.length) {
    const amount = Math.min(give[i].v, get[j].v);
    if (amount > 0) out.push({ from: give[i].id, to: get[j].id, amount });
    give[i].v -= amount; get[j].v -= amount;
    if (give[i].v === 0) i++;
    if (get[j].v === 0) j++;
  }
  return out;
}

/** Balance between two people. Positive = `other` owes `me`. */
export function pairBalance(expenses: Expense[], settlements: Settlement[], me: string, other: string): number {
  let bal = 0;
  for (const e of expenses) for (const d of expenseDebts(e)) {
    if (d.from === other && d.to === me) bal += d.amount;
    if (d.from === me && d.to === other) bal -= d.amount;
  }
  for (const s of settlements) {
    if (s.fromId === other && s.toId === me) bal -= s.amountMinor;
    if (s.fromId === me && s.toId === other) bal += s.amountMinor;
  }
  return bal;
}

/** Everything you owe / are owed, grouped per person. */
export function myTotals(expenses: Expense[], settlements: Settlement[], me: string, others: string[]) {
  let owe = 0, owed = 0;
  const per: Record<string, number> = {};
  for (const o of others) {
    const b = pairBalance(expenses, settlements, me, o);
    per[o] = b;
    if (b > 0) owed += b; else owe += -b;
  }
  return { owe, owed, per };
}

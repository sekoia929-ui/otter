// Run with: npm run test:logic
import assert from 'node:assert/strict';
import { splitEqual, splitPercent, sumLines } from './splits';
import { expenseDebts, netBalances, pairBalance, simplifyDebts } from './balances';
import { formatMoney, parseMinor } from './money';
import type { Expense, Settlement } from './types';

assert.equal(parseMinor('12.5'), 1250); assert.equal(parseMinor('0.07'), 7); assert.equal(parseMinor('abc'), null); assert.equal(parseMinor('1.234'), null);
assert.equal(formatMoney(123456, 'USD'), '$1,234.56');
const eq = splitEqual(1000, ['a', 'b', 'c']); assert.equal(sumLines(eq), 1000); assert.deepEqual(eq.map((l) => l.amountMinor), [334, 333, 333]);
const pc = splitPercent(1001, { a: 33.33, b: 33.33, c: 33.34 }); assert.equal(sumLines(pc), 1001);

const ex = (payments: [string, number][], splits: [string, number][]): Expense => ({ id: 'x', description: '', amountMinor: payments.reduce((s, p) => s + p[1], 0), currency: 'USD', category: 'food', date: '', paymentMethod: 'cash', groupId: null,
  payments: payments.map(([userId, amountMinor]) => ({ userId, amountMinor })), splits: splits.map(([userId, amountMinor]) => ({ userId, amountMinor })), createdAt: '', updatedAt: '', syncStatus: 'synced' });

// me paid 90, split three ways -> a and b each owe me 30
const e1 = ex([['me', 9000]], [['me', 3000], ['a', 3000], ['b', 3000]]);
assert.equal(pairBalance([e1], [], 'me', 'a'), 3000);
// multiple payers: a paid 60, b paid 30, equal split of 90 among a,b,me -> me owes a 30? me share 30; a net +30, b net 0
const e2 = ex([['a', 6000], ['b', 3000]], [['me', 3000], ['a', 3000], ['b', 3000]]);
assert.equal(pairBalance([e2], [], 'me', 'a'), -3000);
const debts = expenseDebts(e2); assert.equal(debts.reduce((s, d) => s + d.amount, 0), 3000);
// settlement reduces balance
const st: Settlement = { id: 's', fromId: 'a', toId: 'me', amountMinor: 1000, currency: 'USD', groupId: null, date: '', note: '', syncStatus: 'synced' };
assert.equal(pairBalance([e1], [st], 'me', 'a'), 2000);
// net balances always sum to zero and simplification pays everyone off
const net = netBalances([e1, e2], []); assert.equal(Object.values(net).reduce((s, v) => s + v, 0), 0);
const plan = simplifyDebts(net); const check = { ...net }; plan.forEach((d) => { check[d.from] += d.amount; check[d.to] -= d.amount; });
assert.ok(Object.values(check).every((v) => v === 0));
console.log('✓ all logic tests passed');

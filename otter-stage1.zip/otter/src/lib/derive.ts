// Read-only helpers that turn raw store data into numbers for screens.
import { categoryOf, CATEGORIES, CategoryId } from './categories';
import { inRange, monthRange, startOfWeek } from './dates';
import { Expense, ME, Settlement, isShared } from './types';

/** What an expense cost ME (my share), in minor units. */
export const myShare = (e: Expense) => e.splits.find((s) => s.userId === ME)?.amountMinor ?? 0;
export const sortNewest = (a: Expense, b: Expense) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt);
export const sum = (xs: number[]) => xs.reduce((a, b) => a + b, 0);

export function spendInRange(expenses: Expense[], start: Date, end: Date, onlyPersonal = false) {
  return sum(expenses.filter((e) => inRange(e.date, start, end) && (!onlyPersonal || !isShared(e))).map(myShare));
}
export function categoryTotals(expenses: Expense[], start: Date, end: Date) {
  const inM = expenses.filter((e) => inRange(e.date, start, end));
  return CATEGORIES.map((c) => ({ ...c, total: sum(inM.filter((e) => e.category === c.id).map(myShare)) }))
    .filter((c) => c.total > 0).sort((a, b) => b.total - a.total);
}
/** Last 7 days (oldest first) for the small bar chart. */
export function last7Days(expenses: Expense[]) {
  const out: { label: string; value: number; today: boolean }[] = [];
  for (let i = 6; i >= 0; i--) {
    const a = new Date(); a.setDate(a.getDate() - i); a.setHours(0, 0, 0, 0);
    const b = new Date(a); b.setDate(b.getDate() + 1);
    out.push({ label: a.toLocaleDateString(undefined, { weekday: 'short' }).slice(0, 2), value: spendInRange(expenses, a, b), today: i === 0 });
  }
  return out;
}
/** Last 6 months (oldest first). */
export function last6Months(expenses: Expense[]) {
  const out: { label: string; value: number; today: boolean }[] = [];
  for (let i = 5; i >= 0; i--) {
    const r = monthRange(-i);
    out.push({ label: r.start.toLocaleDateString(undefined, { month: 'short' }), value: spendInRange(expenses, r.start, r.end), today: i === 0 });
  }
  return out;
}
export function weekCompare(expenses: Expense[]) {
  const s = startOfWeek(); const prev = new Date(s); prev.setDate(prev.getDate() - 7); const next = new Date(s); next.setDate(next.getDate() + 7);
  return { thisWeek: spendInRange(expenses, s, next), lastWeek: spendInRange(expenses, prev, s) };
}
export const pctChange = (now: number, before: number) => (before === 0 ? null : Math.round(((now - before) / before) * 100));
export const groupExpenses = (expenses: Expense[], gid: string) => expenses.filter((e) => e.groupId === gid);
export const groupSettlements = (settlements: Settlement[], gid: string) => settlements.filter((s) => s.groupId === gid);
export { categoryOf };
export type { CategoryId };

import { create } from 'zustand';
import { newId } from '@/lib/id';
import { Expense, Group, ME, Person, Settlement } from '@/lib/types';
import { sampleExpenses, sampleGroups, samplePeople, sampleProfile, sampleSettlements } from '@/data/sample';

export type Settings = {
  currency: string;
  theme: 'system' | 'light' | 'dark';
  notifications: { reminders: boolean; friendRequests: boolean; settlements: boolean };
};

type NewExpense = Omit<Expense, 'id' | 'createdAt' | 'updatedAt' | 'syncStatus'>;

type State = {
  // session
  onboarded: boolean; signedIn: boolean;
  /** Stage 1 only: lets you preview offline UI. Stage 4 replaces this with real network status. */
  simulateOffline: boolean;
  profile: { name: string; email: string };
  settings: Settings;
  // data (Stage 2 moves this into SQLite)
  people: Person[]; groups: Group[]; expenses: Expense[]; settlements: Settlement[];

  finishOnboarding: () => void;
  signIn: (name?: string, email?: string) => void;
  signOut: () => void;
  setSettings: (patch: Partial<Settings>) => void;
  setNotification: (k: keyof Settings['notifications'], v: boolean) => void;
  setProfile: (p: Partial<State['profile']>) => void;
  toggleOffline: () => void;

  addExpense: (e: NewExpense) => string;
  updateExpense: (id: string, e: Partial<NewExpense>) => void;
  deleteExpense: (id: string) => void;

  addGroup: (name: string, emoji: string, memberIds: string[]) => string;
  addSettlement: (s: Omit<Settlement, 'id' | 'syncStatus'>) => void;

  sendFriendRequest: (name: string, email: string) => void;
  acceptRequest: (id: string) => void;
  declineRequest: (id: string) => void;
};

const stamp = () => new Date().toISOString();

export const useStore = create<State>((set) => ({
  onboarded: false, signedIn: false, simulateOffline: false,
  profile: sampleProfile,
  settings: { currency: 'USD', theme: 'system', notifications: { reminders: true, friendRequests: true, settlements: true } },
  people: samplePeople, groups: sampleGroups, expenses: sampleExpenses, settlements: sampleSettlements,

  finishOnboarding: () => set({ onboarded: true }),
  signIn: (name, email) => set((s) => ({ signedIn: true, profile: { name: name || s.profile.name, email: email || s.profile.email } })),
  signOut: () => set({ signedIn: false }),
  setSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),
  setNotification: (k, v) => set((s) => ({ settings: { ...s.settings, notifications: { ...s.settings.notifications, [k]: v } } })),
  setProfile: (p) => set((s) => ({ profile: { ...s.profile, ...p } })),
  toggleOffline: () => set((s) => ({ simulateOffline: !s.simulateOffline })),

  addExpense: (e) => {
    const id = newId();
    set((s) => ({ expenses: [{ ...e, id, createdAt: stamp(), updatedAt: stamp(), syncStatus: 'pending' }, ...s.expenses] }));
    return id;
  },
  updateExpense: (id, patch) => set((s) => ({ expenses: s.expenses.map((x) => (x.id === id ? { ...x, ...patch, updatedAt: stamp(), syncStatus: 'pending' } : x)) })),
  deleteExpense: (id) => set((s) => ({ expenses: s.expenses.filter((x) => x.id !== id) })),

  addGroup: (name, emoji, memberIds) => {
    const id = newId();
    set((s) => ({ groups: [{ id, name, emoji, memberIds: [ME, ...memberIds.filter((m) => m !== ME)], createdAt: stamp() }, ...s.groups] }));
    return id;
  },
  addSettlement: (st) => set((s) => ({ settlements: [{ ...st, id: newId(), syncStatus: 'pending' }, ...s.settlements] })),

  sendFriendRequest: (name, email) => set((s) => ({ people: [...s.people, { id: newId(), name: name || email.split('@')[0], email, status: 'outgoing' }] })),
  acceptRequest: (id) => set((s) => ({ people: s.people.map((p) => (p.id === id ? { ...p, status: 'friend' } : p)) })),
  declineRequest: (id) => set((s) => ({ people: s.people.filter((p) => p.id !== id) })),
}));

export const personName = (people: Person[], id: string, profileName?: string) =>
  id === ME ? 'You' : people.find((p) => p.id === id)?.name ?? profileName ?? 'Unknown';

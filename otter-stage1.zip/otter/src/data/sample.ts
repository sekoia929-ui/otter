// Realistic sample data for Stage 1. Stage 2 replaces this with SQLite.
import { daysAgo } from '@/lib/dates';
import { splitEqual } from '@/lib/splits';
import { newId } from '@/lib/id';
import { CategoryId, PaymentMethod } from '@/lib/categories';
import { Expense, Group, Line, ME, Person, Settlement } from '@/lib/types';

export const sampleProfile = { name: 'Alex Rivera', email: 'alex@otter.app' };

export const samplePeople: Person[] = [
  { id: 'p-mia', name: 'Mia Chen', email: 'mia@mail.com', status: 'friend' },
  { id: 'p-jonas', name: 'Jonas Weber', email: 'jonas@mail.com', status: 'friend' },
  { id: 'p-aarav', name: 'Aarav Patel', email: 'aarav@mail.com', status: 'friend' },
  { id: 'p-priya', name: 'Priya Nair', email: 'priya@mail.com', status: 'friend' },
  { id: 'p-lena', name: 'Lena Novak', email: 'lena@mail.com', status: 'friend' },
  { id: 'p-sam', name: 'Sam Okafor', email: 'sam@mail.com', status: 'incoming' },
  { id: 'p-noor', name: 'Noor Haddad', email: 'noor@mail.com', status: 'outgoing' },
];

export const sampleGroups: Group[] = [
  { id: 'g-flat', name: 'Flat 4B', emoji: '🏠', memberIds: [ME, 'p-mia', 'p-jonas'], createdAt: daysAgo(90) },
  { id: 'g-trip', name: 'Weekend trip', emoji: '🏔️', memberIds: [ME, 'p-aarav', 'p-priya', 'p-lena'], createdAt: daysAgo(30) },
];

const now = daysAgo(0);
function personal(description: string, amount: number, category: CategoryId, ago: number, pm: PaymentMethod = 'card'): Expense {
  return { id: newId(), description, amountMinor: amount, currency: 'USD', category, date: daysAgo(ago, 9 + (ago % 9)), paymentMethod: pm,
    groupId: null, payments: [{ userId: ME, amountMinor: amount }], splits: [{ userId: ME, amountMinor: amount }], createdAt: now, updatedAt: now, syncStatus: 'synced' };
}
function shared(description: string, amount: number, category: CategoryId, ago: number, groupId: string | null,
  payer: string, members: string[], pm: PaymentMethod = 'card', extraPayments?: Line[]): Expense {
  return { id: newId(), description, amountMinor: amount, currency: 'USD', category, date: daysAgo(ago, 19), paymentMethod: pm, groupId,
    payments: extraPayments ?? [{ userId: payer, amountMinor: amount }], splits: splitEqual(amount, members), createdAt: now, updatedAt: now, syncStatus: 'synced' };
}

const flat = [ME, 'p-mia', 'p-jonas'];
const trip = [ME, 'p-aarav', 'p-priya', 'p-lena'];

export const sampleExpenses: Expense[] = [
  personal('Coffee & croissant', 640, 'food', 0, 'card'),
  personal('Metro top-up', 2000, 'transport', 1, 'mobile'),
  personal('Lunch bowl', 1480, 'food', 2, 'cash'),
  personal('Pharmacy', 1890, 'healthcare', 3, 'card'),
  personal('Running shoes', 8900, 'shopping', 5, 'card'),
  personal('Online course', 4900, 'education', 8, 'bank'),
  personal('Cinema', 1600, 'entertainment', 9, 'card'),
  personal('Groceries', 5320, 'food', 11, 'card'),
  personal('Taxi home', 1850, 'transport', 14, 'cash'),
  personal('Phone plan', 2500, 'housing', 17, 'bank'),
  personal('Book bundle', 3400, 'education', 21, 'card'),
  personal('Groceries', 6140, 'food', 26, 'card'),
  personal('Gym month', 3500, 'others', 30, 'bank'),
  personal('Jacket', 12900, 'shopping', 35, 'card'),
  personal('Dentist', 7500, 'healthcare', 41, 'card'),
  shared('Rent', 120000, 'housing', 1, 'g-flat', ME, flat, 'bank'),
  shared('Electricity', 9000, 'housing', 6, 'g-flat', 'p-mia', flat, 'bank'),
  shared('Pizza night', 5400, 'food', 10, 'g-flat', 'p-jonas', flat, 'card'),
  shared('Internet', 3000, 'housing', 24, 'g-flat', ME, flat, 'bank'),
  shared('Cabin rental', 48000, 'housing', 18, 'g-trip', 'p-aarav', trip, 'card'),
  shared('Fuel & tolls', 12400, 'transport', 17, 'g-trip', ME, trip, 'card'),
  shared('Dinner at the lodge', 18800, 'food', 16, 'g-trip', 'p-priya', trip, 'card', [
    { userId: 'p-priya', amountMinor: 10000 }, { userId: 'p-lena', amountMinor: 8800 }]),
  shared('Lunch with Mia', 3600, 'food', 4, null, 'p-mia', [ME, 'p-mia'], 'cash'),
];

export const sampleSettlements: Settlement[] = [
  { id: newId(), fromId: 'p-jonas', toId: ME, amountMinor: 10000, currency: 'USD', groupId: 'g-flat', date: daysAgo(3), note: 'Part of rent', syncStatus: 'synced' },
];

import React from 'react';
import { ActivityIndicator, Image, Pressable, ScrollView, StyleProp, Switch, Text, TextInput, TextInputProps, TextStyle, View, ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useTheme } from '@/theme/ThemeProvider';
import { radius, space } from '@/theme/colors';
import { useStore } from '@/store/useStore';

type IconName = React.ComponentProps<typeof Ionicons>['name'];
const VARIANTS = {
  display: { fontSize: 36, fontWeight: '800', letterSpacing: -1.2 },
  title: { fontSize: 26, fontWeight: '800', letterSpacing: -0.6 },
  h2: { fontSize: 18, fontWeight: '800', letterSpacing: -0.2 },
  body: { fontSize: 15, fontWeight: '500' },
  strong: { fontSize: 15, fontWeight: '700' },
  small: { fontSize: 13, fontWeight: '500' },
  label: { fontSize: 12, fontWeight: '700', letterSpacing: 0.6, textTransform: 'uppercase' },
} as const;

type TxtProps = React.ComponentProps<typeof Text> & { v?: keyof typeof VARIANTS; muted?: boolean; color?: string };
export function Txt({ v = 'body', muted, color, style, ...rest }: TxtProps) {
  const { colors } = useTheme();
  return <Text {...rest} style={[VARIANTS[v] as TextStyle, { color: color ?? (muted ? colors.muted : colors.text) }, style]} />;
}

export function Logo({ size = 96 }: { size?: number }) {
  return <Image accessibilityLabel="OTTER logo" source={require('../../assets/otter-logo.png')} style={{ width: size, height: size * (772 / 788) }} resizeMode="contain" />;
}

export function Screen({ children, scroll = true, edges = ['top'], style, bg }: { children: React.ReactNode; scroll?: boolean; edges?: ('top' | 'bottom')[]; style?: StyleProp<ViewStyle>; bg?: string }) {
  const { colors } = useTheme();
  return (
    <SafeAreaView edges={edges} style={{ flex: 1, backgroundColor: bg ?? colors.bg }}>
      {scroll ? (
        <ScrollView contentContainerStyle={[{ padding: 20, paddingBottom: 120, gap: space.lg }, style]} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">{children}</ScrollView>
      ) : (
        <View style={[{ flex: 1, padding: 20 }, style]}>{children}</View>
      )}
    </SafeAreaView>
  );
}

export function Header({ title, right, back = true }: { title: string; right?: React.ReactNode; back?: boolean }) {
  const router = useRouter(); const { colors } = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 48 }}>
      {back && (
        <Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={() => (router.canGoBack() ? router.back() : router.replace('/'))}
          style={{ width: 44, height: 44, borderRadius: 22, borderWidth: 1.5, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="chevron-back" size={22} color={colors.text} />
        </Pressable>
      )}
      <Txt v="title" style={{ flex: 1 }} numberOfLines={1}>{title}</Txt>
      {right}
    </View>
  );
}

export function Card({ children, style, soft, onPress }: { children: React.ReactNode; style?: StyleProp<ViewStyle>; soft?: boolean; onPress?: () => void }) {
  const { colors } = useTheme();
  const base: ViewStyle = { backgroundColor: soft ? colors.soft : colors.card, borderRadius: radius.lg, padding: space.lg, borderWidth: soft ? 0 : 1.5, borderColor: colors.border };
  if (onPress) return <Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [base, style, pressed && { opacity: 0.85 }]}>{children}</Pressable>;
  return <View style={[base, style]}>{children}</View>;
}

export function Button({ title, onPress, variant = 'primary', icon, disabled, loading, style }: { title: string; onPress?: () => void; variant?: 'primary' | 'brand' | 'outline' | 'danger' | 'ghost'; icon?: IconName; disabled?: boolean; loading?: boolean; style?: StyleProp<ViewStyle> }) {
  const { colors } = useTheme();
  const map = {
    primary: { bg: colors.inverse, fg: colors.onInverse, border: colors.inverse },
    brand: { bg: colors.primary, fg: colors.onPrimary, border: colors.primary },
    outline: { bg: 'transparent', fg: colors.text, border: colors.border },
    danger: { bg: 'transparent', fg: colors.negative, border: colors.negative },
    ghost: { bg: 'transparent', fg: colors.text, border: 'transparent' },
  }[variant];
  return (
    <Pressable accessibilityRole="button" accessibilityState={{ disabled: !!disabled }} disabled={disabled || loading} onPress={onPress}
      style={({ pressed }) => [{ minHeight: 52, borderRadius: radius.pill, paddingHorizontal: 22, backgroundColor: map.bg, borderColor: map.border, borderWidth: 1.5, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, opacity: disabled ? 0.4 : pressed ? 0.85 : 1 }, style]}>
      {loading ? <ActivityIndicator color={map.fg} /> : (<>
        {icon && <Ionicons name={icon} size={20} color={map.fg} />}
        <Text style={{ color: map.fg, fontSize: 16, fontWeight: '800' }}>{title}</Text></>)}
    </Pressable>
  );
}

export function Field({ label, error, ...rest }: TextInputProps & { label?: string; error?: string | null }) {
  const { colors } = useTheme();
  return (
    <View style={{ gap: 6 }}>
      {label && <Txt v="label" muted>{label}</Txt>}
      <TextInput placeholderTextColor={colors.muted} accessibilityLabel={label} {...rest}
        style={[{ minHeight: 52, borderRadius: radius.md, borderWidth: 1.5, borderColor: error ? colors.negative : colors.border, paddingHorizontal: 16, fontSize: 16, fontWeight: '600', color: colors.text, backgroundColor: colors.card }, rest.style]} />
      {error ? <Txt v="small" color={colors.negative}>{error}</Txt> : null}
    </View>
  );
}

export function Chip({ label, selected, onPress, icon, color, disabled }: { label: string; selected?: boolean; onPress?: () => void; icon?: IconName; color?: string; disabled?: boolean }) {
  const { colors } = useTheme();
  return (
    <Pressable accessibilityRole="button" accessibilityState={{ selected: !!selected, disabled: !!disabled }} onPress={onPress} disabled={disabled}
      style={{ minHeight: 44, paddingHorizontal: 14, borderRadius: radius.pill, flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1.5, opacity: disabled ? 0.45 : 1,
        borderColor: selected ? colors.inverse : colors.border, backgroundColor: selected ? colors.inverse : 'transparent' }}>
      {icon && <Ionicons name={icon} size={16} color={selected ? colors.onInverse : color ?? colors.text} />}
      <Text style={{ fontWeight: '700', fontSize: 14, color: selected ? colors.onInverse : colors.text }}>{label}</Text>
    </Pressable>
  );
}

export function Segmented<T extends string>({ options, value, onChange }: { options: { id: T; label: string }[]; value: T; onChange: (v: T) => void }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: 'row', backgroundColor: colors.soft, borderRadius: radius.pill, padding: 4 }}>
      {options.map((o) => {
        const on = o.id === value;
        return (
          <Pressable key={o.id} accessibilityRole="button" accessibilityState={{ selected: on }} onPress={() => onChange(o.id)}
            style={{ flex: 1, minHeight: 44, alignItems: 'center', justifyContent: 'center', borderRadius: radius.pill, backgroundColor: on ? colors.inverse : 'transparent' }}>
            <Text style={{ fontWeight: '800', fontSize: 14, color: on ? colors.onInverse : colors.text }}>{o.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const AV = ['#FFD83D', '#67C6FE', '#39B982', '#F7A8C4', '#B7A4F5', '#F59B7A'];
export function Avatar({ name, size = 44 }: { name: string; size?: number }) {
  const h = [...name].reduce((a, c) => a + c.charCodeAt(0), 0);
  const initials = name.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  return (
    <View accessibilityLabel={`${name} avatar`} style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: AV[h % AV.length], alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#080808' }}>
      <Text style={{ fontWeight: '800', fontSize: size * 0.36, color: '#080808' }}>{initials}</Text>
    </View>
  );
}

export function IconBubble({ name, color, size = 44 }: { name: IconName; color: string; size?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size * 0.36, backgroundColor: color, alignItems: 'center', justifyContent: 'center' }}>
      <Ionicons name={name} size={size * 0.48} color="#080808" />
    </View>
  );
}

export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 }}>
      <Txt v="h2">{title}</Txt>
      {action && <Pressable accessibilityRole="button" onPress={onAction} hitSlop={12} style={{ minHeight: 44, justifyContent: 'center' }}><Txt v="strong" color={colors.text} style={{ textDecorationLine: 'underline' }}>{action}</Txt></Pressable>}
    </View>
  );
}

export function Row({ left, title, subtitle, right, onPress, last }: { left?: React.ReactNode; title: string; subtitle?: string; right?: React.ReactNode; onPress?: () => void; last?: boolean }) {
  const { colors } = useTheme();
  const body = (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 64, paddingVertical: 8, borderBottomWidth: last ? 0 : 1, borderBottomColor: colors.border }}>
      {left}
      <View style={{ flex: 1 }}>
        <Txt v="strong" numberOfLines={1}>{title}</Txt>
        {subtitle ? <Txt v="small" muted numberOfLines={1}>{subtitle}</Txt> : null}
      </View>
      {right}
    </View>
  );
  return onPress ? <Pressable accessibilityRole="button" onPress={onPress}>{body}</Pressable> : body;
}

export function EmptyState({ icon = 'sparkles-outline', title, text, action, onAction }: { icon?: IconName; title: string; text: string; action?: string; onAction?: () => void }) {
  const { colors } = useTheme();
  return (
    <View style={{ alignItems: 'center', gap: 10, paddingVertical: 36, paddingHorizontal: 24 }}>
      <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: colors.soft, alignItems: 'center', justifyContent: 'center' }}><Ionicons name={icon} size={28} color={colors.text} /></View>
      <Txt v="h2" style={{ textAlign: 'center' }}>{title}</Txt>
      <Txt muted style={{ textAlign: 'center' }}>{text}</Txt>
      {action && <Button title={action} onPress={onAction} variant="brand" style={{ marginTop: 8 }} />}
    </View>
  );
}

export function ErrorBanner({ message }: { message: string }) {
  const { colors } = useTheme();
  return (
    <View accessibilityRole="alert" style={{ flexDirection: 'row', gap: 10, padding: 12, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.negative, alignItems: 'center' }}>
      <Ionicons name="alert-circle" size={20} color={colors.negative} /><Txt v="small" color={colors.negative} style={{ flex: 1, fontWeight: '700' }}>{message}</Txt>
    </View>
  );
}

/** Shown on every data screen when offline: what still works, what needs internet. */
export function OfflineBanner() {
  const offline = useStore((s) => s.simulateOffline);
  const { colors } = useTheme();
  if (!offline) return null;
  return (
    <View accessibilityRole="alert" style={{ flexDirection: 'row', gap: 10, padding: 12, borderRadius: radius.md, backgroundColor: colors.warning, alignItems: 'center' }}>
      <Ionicons name="cloud-offline" size={20} color="#080808" />
      <Txt v="small" color="#080808" style={{ flex: 1, fontWeight: '700' }}>Offline — everything you add is saved on this device and syncs when you're back online.</Txt>
    </View>
  );
}

export function Pill({ text, tone = 'soft' }: { text: string; tone?: 'soft' | 'yellow' | 'green' | 'red' }) {
  const { colors } = useTheme();
  const bg = { soft: colors.soft, yellow: '#FFD83D', green: '#39B982', red: '#FFD9DA' }[tone];
  const fg = tone === 'soft' ? colors.text : '#080808';
  return <View style={{ alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.pill, backgroundColor: bg }}><Text style={{ fontSize: 11, fontWeight: '800', color: fg }}>{text}</Text></View>;
}
export const ComingSoon = () => <Pill text="COMING SOON" tone="yellow" />;
export const NeedsInternet = () => <Pill text="NEEDS INTERNET" tone="soft" />;

export function ToggleRow({ title, subtitle, value, onChange }: { title: string; subtitle?: string; value: boolean; onChange: (v: boolean) => void }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 60 }}>
      <View style={{ flex: 1 }}><Txt v="strong">{title}</Txt>{subtitle ? <Txt v="small" muted>{subtitle}</Txt> : null}</View>
      <Switch accessibilityLabel={title} value={value} onValueChange={onChange} trackColor={{ true: colors.primary, false: colors.border }} thumbColor="#FFFFFF" />
    </View>
  );
}

import React from 'react';
import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Expense, ME, isShared } from '@/lib/types';
import { categoryOf } from '@/lib/categories';
import { formatMoney } from '@/lib/money';
import { prettyDate } from '@/lib/dates';
import { myShare } from '@/lib/derive';
import { personName, useStore } from '@/store/useStore';
import { useTheme } from '@/theme/ThemeProvider';
import { IconBubble, Row, Txt } from './ui';

export function ExpenseRow({ e, last }: { e: Expense; last?: boolean }) {
  const router = useRouter(); const { colors } = useTheme();
  const people = useStore((s) => s.people); const profile = useStore((s) => s.profile);
  const cat = categoryOf(e.category);
  const shared = isShared(e);
  const payer = e.payments.length > 1 ? 'multiple people' : personName(people, e.payments[0]?.userId ?? ME, profile.name);
  const sub = shared ? `${prettyDate(e.date)} · ${payer === 'You' ? 'You paid' : payer + ' paid'}` : `${prettyDate(e.date)} · ${cat.label}`;
  return (
    <Row onPress={() => router.push(`/expense/${e.id}`)} last={last} left={<IconBubble name={cat.icon} color={cat.color} />} title={e.description} subtitle={sub}
      right={
        <View style={{ alignItems: 'flex-end' }}>
          <Txt v="strong">{formatMoney(shared ? myShare(e) : e.amountMinor, e.currency)}</Txt>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            {e.syncStatus !== 'synced' && <Ionicons name="cloud-upload-outline" size={12} color={colors.muted} />}
            <Txt v="small" muted>{shared ? `of ${formatMoney(e.amountMinor, e.currency)}` : e.syncStatus === 'synced' ? '' : 'On device'}</Txt>
          </View>
        </View>
      } />
  );
}

import React from 'react';
import { View, Text } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { useTheme } from '@/theme/ThemeProvider';
import { Txt } from './ui';

/** Simple bar chart built from Views (no chart library needed). */
export function Bars({ data, height = 120, onFormat }: { data: { label: string; value: number; today?: boolean }[]; height?: number; onFormat?: (v: number) => string }) {
  const { colors } = useTheme();
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <View accessibilityRole="image" accessibilityLabel={`Bar chart. ${data.map((d) => `${d.label}: ${onFormat ? onFormat(d.value) : d.value}`).join(', ')}`}
      style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8, height: height + 24 }}>
      {data.map((d, i) => (
        <View key={i} style={{ flex: 1, alignItems: 'center', gap: 6 }}>
          <View style={{ height, justifyContent: 'flex-end', width: '100%' }}>
            <View style={{ height: Math.max(4, (d.value / max) * height), borderRadius: 8, backgroundColor: d.today ? colors.primary : colors.soft, borderWidth: d.today ? 0 : 1.5, borderColor: colors.border }} />
          </View>
          <Text style={{ fontSize: 11, fontWeight: d.today ? '800' : '600', color: d.today ? colors.text : colors.muted }}>{d.label}</Text>
        </View>
      ))}
    </View>
  );
}

export function Donut({ slices, size = 150, centerTop, centerBottom }: { slices: { value: number; color: string }[]; size?: number; centerTop?: string; centerBottom?: string }) {
  const { colors } = useTheme();
  const stroke = 22; const r = (size - stroke) / 2; const c = 2 * Math.PI * r;
  const total = slices.reduce((s, x) => s + x.value, 0) || 1;
  let offset = 0;
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }} accessibilityRole="image" accessibilityLabel="Spending by category donut chart">
      <Svg width={size} height={size} style={{ position: 'absolute', transform: [{ rotate: '-90deg' }] }}>
        <Circle cx={size / 2} cy={size / 2} r={r} stroke={colors.soft} strokeWidth={stroke} fill="none" />
        {slices.map((s, i) => {
          const len = (s.value / total) * c; const el = (
            <Circle key={i} cx={size / 2} cy={size / 2} r={r} stroke={s.color} strokeWidth={stroke} fill="none"
              strokeDasharray={`${Math.max(0, len - 3)} ${c}`} strokeDashoffset={-offset} />); offset += len; return el;
        })}
      </Svg>
      <Txt v="small" muted>{centerTop}</Txt>
      <Txt v="h2">{centerBottom}</Txt>
    </View>
  );
}

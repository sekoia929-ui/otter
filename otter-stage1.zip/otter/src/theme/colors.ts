// All brand colours live here. Change a value once and the whole app follows.
export const brand = {
  // Sampled from the supplied logo image (#67C6FE). Your brief said #63BDF1 —
  // swap this one line if you prefer that exact value.
  blue: '#67C6FE',
  black: '#080808',
  white: '#FFFFFF',
  lightBlue: '#EAF6FF',
  yellow: '#FFD83D',
  green: '#39B982',
  red: '#E5484D',
};

export type Palette = {
  bg: string; card: string; soft: string; border: string;
  text: string; muted: string; primary: string; onPrimary: string;
  inverse: string; onInverse: string;
  positive: string; negative: string; warning: string; overlay: string;
};

export const light: Palette = {
  bg: '#FFFFFF', card: '#FFFFFF', soft: brand.lightBlue, border: '#D9E9F5',
  text: brand.black, muted: '#5C6B77', primary: brand.blue, onPrimary: brand.black,
  inverse: brand.black, onInverse: brand.white,
  positive: '#1F9D6B', negative: '#D03A3F', warning: brand.yellow, overlay: 'rgba(8,8,8,0.45)',
};

export const dark: Palette = {
  bg: brand.black, card: '#141516', soft: '#10222E', border: '#26292C',
  text: brand.white, muted: '#9AA6B0', primary: brand.blue, onPrimary: brand.black,
  inverse: brand.white, onInverse: brand.black,
  positive: brand.green, negative: '#FF7478', warning: brand.yellow, overlay: 'rgba(0,0,0,0.65)',
};

export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 };
export const radius = { sm: 10, md: 16, lg: 24, pill: 999 };

import React, { createContext, useContext } from 'react';
import { useColorScheme } from 'react-native';
import { dark, light, Palette } from './colors';
import { useStore } from '@/store/useStore';

type Ctx = { colors: Palette; isDark: boolean };
const ThemeCtx = createContext<Ctx>({ colors: light, isDark: false });

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useColorScheme();
  const pref = useStore((s) => s.settings.theme);
  const isDark = pref === 'system' ? system === 'dark' : pref === 'dark';
  return <ThemeCtx.Provider value={{ colors: isDark ? dark : light, isDark }}>{children}</ThemeCtx.Provider>;
}
export const useTheme = () => useContext(ThemeCtx);
